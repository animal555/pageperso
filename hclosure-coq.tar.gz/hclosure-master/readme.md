Contents
========

* finset.v: mostly a prelude
* morelist.v: some more lemmas about lists
* morewf.v: some more lemmas about well-founded relations
* nestedfan.v: definition of trees and proof of the nested fan theorem
* hwf.v: h-wellfoundedness and proof of the h-closure theorem
* terminator.v: termination theorem of Podelski and Rybalchenko through h-closure
* ramsey.v: proof of ramsey theorem with h-closure+EM

References
==========

S. Berardi, S. Steila
An intuitionistic version of Ramsey's Theorem and its use in Program Termination.
http://www.sciencedirect.com/science/article/pii/S0168007215000731

Related talk
http://logicatorino.altervista.org/steila/slides/Vienna2014RTATLCA.pdf

D. Vytiniotis, T. Coquand, D. Wahlstedt
Stop When You Are Almost-Full
https://link.springer.com/chapter/10.1007/978-3-642-32347-8_17
