Compilation
===========

`make` to compile the code (`make clean` to clean up)


Contents
========

injective(f):= Π x y. f x = f y -> x = y

isomorphism(f):= Σ

hprop(A):= Π a b : A. a = b

hset(A):= Π a b : A. hprop(a = b)

EM:= Π A. A + ¬ A

PEM:= Π A. hprop A -> A + ¬ A

Omniscient(A):= Π s : A -> 2. (Σ n : A. s n = 1) + (Π n : A. s n = 0)

LPO:= Π s : Omniscient(ℕ)


We take Cantor-Bernstein for hsets to be the following statement

Π A B : U. hset A -> hset B -> Π f : A -> B. injective f. Π g : B -> A. injective g ->
Σ r : A -> B. isomorphism r

* `prelude.v`: a few definitions
* `hlemmas.v`: stability lemmas for hprop and hset
* `ninfty.v`: Omniscient(ℕ∞) and other basic facts
* `bar.v`: a quick justification of our conversation in the bar (no dependencies on this file)
* `exercise.v`: a straightforward proof of Cantor-Bernstein from EM (w/o hsets)
* `withlpo.v`: essentially the same proof from LPO + decidability of the range of f and g
* `withpem.v`: Cantor-Bernstein for hsets following from pem (essentially pem implies the assumption of withlpo.v)
* `topem.v`: PEM from Cantor-Bernstein for hsets

Assumptions
===========

All results hold in MLTT + functional extensionality (assumed here (and following from univalence))
Π A B : U. Π f g : A -> B. (Π a : A. f a = g a) -> f = g

Also note that [Π A. hset(A)] trivializes in lots of models (e.g., syntactic and set-theoretical in particular, but contradicts univalence).

Discussion
==========

The nice part of the story is, in MLTT+funext, Cantor Bernstein is equivalent to propositional excluded middle.

The direct implication follows from this fact: given an omniscient type O and A, if there is a section/retraction pair between O and O + A, then A + ¬ A.

The converse juste follows from noticing that CB is provable from decidability of ranges of the functions involved + LPO. In this proof,
Those conditions guarantee that a predicate C, determining how to patch f and g⁻¹ together to get a bijection, is decidable. It follows
from decidability of ranges and the fact that C is obtained as a fixpoint of height ω.

For mild generalizations of CB, do notice that decidability of range of f and g can be also retrieved when the proof of injectivity
of f induces an isomorphism between f x = f y and x = y (and similarly for g). In particular, when f and g are embeddings, the
conclusion of CB follows from PEM withtout assuming that either A or B are hsets (and conversely, any injective map whose codomain
is an hset is an embedding).
There is no hope to get such a conclusion from mere injectivity (in HoTT, consider the unique maps between 1 and S₁; they are injective
but clearly there is no iso between 1 and S₁).

References
==========


For Omniscient(ℕ∞)

M. H. Escardo

Infinite sets that satistify the principle of omniscience
in any variety of constructive mathematics

http://www.cs.bham.ac.uk/~mhe/papers/omniscient-journal-revised.pdf




Technicalities regarding hsets/hprop are completely covered by the HoTT book.
(we only requires a few stability lemmas, those pertaining to hsets being
unimportant in presence of UIP (because everything is an hset with UIP))

http://saunders.phil.cmu.edu/book/hott-online.pdf
