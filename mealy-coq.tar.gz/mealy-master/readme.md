Equational theory of Mealy machines
===================================

This small development illustrates a basic equational theory for Mealy
machines.

A Mealy machine is a synchronous transducer M : (Q, q₀, δ) : Σ -> Γ where
Q is a finite set of states, q₀ ∈ Q is the initial state and δ is a
transition function Σ × Q -> Γ × Q. Such a tuple induces a function
Str(Σ) -> Str(Γ), where Str(-) designates streams. We call two machines
extensionally equivalent if they induce the same function.

Stream functions induced by Mealy machines are stable by the following
operations:
- composition
- constant functions Str(f) : Str(Σ) -> Str(Γ) arising from f : Σ -> Γ
- fixpoints; for any synchronous stream function F : Str(Σ × Γ) -> Str(Γ),
and b₀ ∈ Γ, there exists a unique stream function G : Str(Σ) -> Str(Γ)
such that G = F ∘ < id, b₀ :: G >

Conversely, those three operations are enough to induce all such stream
functions. Considering them as a term language, we define pairing, projections
identities and the (::) operator. Then, the following deduction system is sound
and complete for the extensional equivalence of underlying Mealy machines:
- extensional equivalence is an equivalence relation

         t ≡ u   t ≡ u   u ≡ v
-----    -----   -------------
t ≡ t    u ≡ t       t ≡ v

- congruences for term constructors and pairing

t ≡ u   v ≡ w          t ≡ u          t ≡ u   v ≡ w
-------------    -----------------    -------------
t ∘ v ≡ u ∘ w    fix a t ≡ fix a u    <t,v> ≡ <u,w>


- ∘ is an associative operator, with identity as units.

----------   ----------   -------------------------
t ∘ id ≡ t   id ∘ t ≡ t   t ∘ (u ∘ v) ≡ (t ∘ u) ∘ v

- constant operator are compatible with composition

----------------------------
Str(f ∘ g) ≡ Str(f) ∘ Str(g)

- the fixpoint is a fixpoint

------------------------------------
fix a t ≡ t ∘ <id, cons a ∘ fix a t>

- the fixpoint is unique

u ≡ t ∘ <id, cons a u>
----------------------
u ≡ fix a t

- cons commutes with constant functions

------------------------------------
cons f(a) ∘ Str(f) ≡ Str(f) ∘ cons a

The Coq formalization stops there.

This system does not deal with statements more complicated than single
equalities. Conjunctions and disjunctions of equalities may be reduced to a
single equality, but this does not say anything about inequalities.
