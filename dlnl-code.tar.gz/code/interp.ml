open Prelude
open Ast
open Red

module type Interp_sig = sig

  type env
  type loc

  include Monad with type 'a t = env -> 'a * env

  val getstate : env t
  val setstate : env -> unit t

  val run : 'a t -> 'a 
  val set : loc -> tm -> unit option t
  val get : loc -> tm option t
  val newp : tm -> loc t
  val free : loc -> unit option t
  val string : string t
  val fresh : loc -> bool t
  val gensym : loc t
  val step : tm -> tm t

end

module Interp : Interp_sig with type loc = int = struct

  type loc = int
  type env = (loc * tm) list

  include StateMon (struct type t = env end)

  let (>>) a b = a >>= const b
  let run t = fst @@ t []

  let set ?(force=false) lo t =
    let rec aux = function [] -> if force then
                                   [lo, t]
                                 else raise Exit
                          | (lo', _) :: tl when lo' = lo -> (lo, t) :: tl
                          | hd :: tl -> hd :: (aux tl) in
    fun e -> try (Some (), aux e) with Exit -> None, e

  let get lo =
     getstate >>=
    let rec aux = function (i, t) :: _  when i = lo -> return (Some t)
                         | (i, _) :: tl -> aux tl
                         | _ -> return None in aux 

  let fresh i = get i >>= function None -> return true 
                                 | Some _ -> return false
  let gensym =
    let rec aux i =
      fresh i >>= fun b -> if b then return i else aux (i + 1) in
    aux 0

  let newp v =
     gensym >>= fun l -> set ~force:true l v >> return l

  let free lo e =
    let rec aux = function (i, _) :: tl when i = lo -> tl
                         | (i, t) :: tl -> (i, t) :: (aux tl)
                         | _ -> raise Exit in
  try (Some (), aux e) with Exit -> (None, e)

  let red t =
    lift @@ fst @@ Redbase.fullred t (fun _ -> false)

  let sub a b c = lift @@ fst @@ Redbase.subst a b c (fun _ -> false)

  let sotm s = string_of_tm ~annot:false s

  let string = getstate >>= let rec aux = 
                               function [] -> return ""
                             | (i, t) :: tl -> aux tl >>= fun re -> return
                                              ((string_of_int i) ^ " |-> " ^ (sotm t) ^
                                               (match tl with
                                                 [] -> ""
                                                | _ :: _ -> "\n" ^ re)) in aux
  let set a b = set a b

  let rec step t =
    let rec nat = function
      TIn Zero -> true
    | TIn (Annot (t, _))
    | TIn (Succ t) -> nat t
    | _ -> false in
    let rec int_of_nat = function
      TIn Zero -> 0
    | TIn Annot (t, _) -> int_of_nat t
    | (TIn (Succ t)) -> 1 + (int_of_nat t)
    | _ -> assert false in
    let rec nat_of_int = function 0 -> TIn Zero | n -> TIn (Succ (nat_of_int (n - 1))) in
    let ret t = return (TIn t) in
    red t >>=
    function (TIn t) ->
     match t with
      Val _ -> ret t
     |LetGet (value, cap, TIn (Bnd (v, Bnd (c, e)))) when nat value ->
         get (int_of_nat value) >>= (function Some sv -> sub v sv (TIn e)
                                            | None -> ret t)
     |LetT (e, TIn (Bnd (v, e'))) -> step e >>= fun e -> ret (LetT(e, TIn (Bnd (v, e'))))
     |Assign(lo, c, v) when nat lo -> set (int_of_nat lo) v >>= (function Some _ -> ret (Val c)
                                                                        | None -> ret t)
     |Free (lo, c) when nat lo -> free (int_of_nat lo) >>=
        (function Some _ -> ret Unit
                | None -> ret t)
     |New v -> newp v >>= fun l -> ret (Val (TIn (F(nat_of_int l, TIn (Var "*")))))
     |LetIrrPair(_, TIn ( Bnd(_, Bnd(_, e))))
     |LetIrrUnit(_, TIn e)
     |LetIrr(_, TIn (Bnd(_, e))) -> ret e
     | _ -> ret t
end




module Top = struct
  open Interp
  include StateMonTrans (struct type t = tm end) (Interp)

let sotm = string_of_tm

let (>>) a  b = a >>= const b

let exe = let no = return None in
          let ret a = return (Some a) in
          function "exit" -> no
                  |"step" -> getstate >>= fun b ->
                           lift (step b) >>= fun a ->
                           setstate a >>
                           ret ((sotm b) ^ "\n    was reduced to\n" ^ (sotm a))
                  |"run"  -> getstate >>= fun b ->
                             lift string >>= fun bs ->
                             let rec fix t = lift (step t) >>= fun e ->
                                if e = t then return t else fix e in fix b >>= fun a ->
                             setstate a >>
                           ret ((sotm b) ^ "\n    was reduced to\n" ^ (sotm a))
                  |"print" -> lift string >>= ret
                  |"help" -> ret ("Available commands:\n" ^
                                     "  run" ^
                                     "  step" ^
                                     "  print" ^
                                     "  help")
                  | _ -> ret ":|"

let rec loop : unit t = fun e ->(return (print_string ">>>"; flush stdout; read_line ()) >>=
                                 exe >>= function Some s -> print_endline s; loop
                                                 | None -> print_endline "..."; return ())  e

let run (a : 'a t) (t : tm) : 'a = fst (run (a t))

end
