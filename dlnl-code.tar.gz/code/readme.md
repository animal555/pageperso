Usage
=====

`make` produces a toplevel `top`, which can then process the command below.
A `;` must be added to signal the end of input within the toplevel but should
not appear in files.
The option `-d` disables debug messages.
Some examples are provided in .dln files attached.

FIXME : For now, if a name is defined at the toplevel, it cannot be replaced.
        If we try to redefine something, we get an error.

* `check term`

    Will try to synthesize the type of the given intuitionnistic term.
    To check, use an annotated term.

    Examples:
      `check 0`
      `check (λ _ x. x) : Π A : U. A ⟶ A`
      
* `val ident [: term] := term`

    Bind a typed term to an identifier.

    Examples:
      `val n := 0`
      `val id : Π A : U. A ⟶ A := λ _ x. x`

* `include "filename"`

    Will run the sequence of commands contained in the file named
    "filename.dln".

* `import "filename"`

    Same as include, but will preprend `filename_` to every free variables
    in terms while processing the file.

* `print`

    Will print out the current state of the environment, i.e. all definitions
    and axioms with the relevant terms and/or types.

* `restart`

    Clear the toplevel environment

* `instantiate ident := term`

    If ident is the name of an axiom in the context, this should check term
    against its type. If this typechecks, ident is removed as an axiom and
    term becomes its definition.

* `generalize ident`

    If ident is the name of an axiom in the context, this command removes it
    and generalize all definitions approprietly

    Example:
      After
      `# axiom A : U;;
       # dupl := A + A;;
       # val id : A ⟶ A := λ x. x;;
       # val z := 0;;
       # generalize A;;`
      the following will typecheck
      `dupl : Π A : U. U`
      `id : ∀ A : U. U`
      `z : ℕ`

Misc
====

* A plain let binding (where the lhs is a variable) is actually equivalent to
  a syntactical substitution; the rhs is not typeckecked at all if the lhs
  does not occur after that.

* `_` is available as a variable name for binders but not plain variables.
  The typechecker currently treats this as any other names.

* When nesting let patterns/putting let patterns in λ-abstraction, the parser
  will unfold those to primitive let bindings with fresh variables. Those are
  prefixed by `%` if they are displayed.

* `J` is weird wrt `∀`. We restrict it to the strictest behaviour for now,
  (i e, when it acts on `e` of type `Eq A x y`, `y` is never relevant and
   `x` can be).

* One can extract a derivation tree from the program by supplying a `--tree`
  option to `top`. This option takes a filename as argument (defaults to
  `tree.out` if the empty string is passed).
  After each synthesis/check, this file will be emptied and a the corresponding
  prooftree will be Marshaled in there.
  A patoline file `tree.txp` is provided to output the content of `tree.out`.
  The type of the Marshaled trees is declared at the end of `ast.ml`

Bugs
====

* `::` and `:` do not have the expected syntactical scope.

  I.e. this will fail :
    check λ x. x : Unit -> Unit

  `run` is also somewhat confusing in this regard...
* ...

Syntax
======

x ∈ Variables
n ∈ ℕ

Commands:
c ::= check e
    | val x : e := e | val x := e
    | axiom x : e
    | compute e
    | instantiate x := e
    | dump
    | restart
    | include
    | import

Terms:

x ∈ Variables
n ∈ ℕ

e   ::= x
      | < e >
      | let ilp = e in e
      | ()
      | UnitInd(x.e, e, e)
      | λ ilp. e | fun ilp. e
      | e e
      | (e, e)
      | π₁ e | fst e
      | π₂ e | snd e
      | sup (e, e)
      | IndW(x. e, x.x.x. e, e)
      | inl e
      | inr e
      | Ind+(x. e, x. e, x. e, e) | IndPlus(x. e, x. e, x. e, e) 
      | refl
      | J(x.x.x. e, e, e)
      | G t
      | n
      | S e
      | Indℕ(x. e, e,x.x. e, e) | IndNat(x. e, e,x.x. e, e)
      | Comp t
      | [ e ]
      | q qlist, e
      | e + e
      | Unit
      | ℕ | Nat
      | U | Un
      | e * e | e ⊗ e
      | e -o e | e ⊸ e
      | I
      | T e
      | L | Ln
      | # t | #n t
      | e : e | e :: e

q   ::= Π | Pi
      | Σ | Sig
      | ∀ | Forall
      | ∃ | Exists
      | Fty
      | W

varlist ::= x | x varlist

qlist ::= varlist : e | varlist : e, qlist

ilp ::= x
      | < ilp >
      | (ilp, ilp)

llp ::= x
      | < llp >
      | F(x, llp)
      | (llp, llp)
      | value llp
      | ()
      | <>
      | pack(llp, llp)
      | < llp, llp >
      | [ llp, llp ]

t   ::= x
      | ()
      | λ x. t | fun x. t
      | t t
      | (t, t)
      | let llp = t in t
      | value t
      | set(e, t, e)
      | let (! x, llp) = get(e, t) in e
      | new e
      | [t , t]
      | run e
      | pack(e, t)
      | < t >
      | Indℕ(x. e, t, x.x. t, e) | IndNat(x.e, t, x.x.t, e) 
      | IndW(x. e, x.x.x. t, e)
      | Ind+(x. e, x. t, x. t, e)
      | IndUnit(x. e, t)
      | IndBot(e) | Ind⊥(e)
      | J(x.y.p. e, t, e)
      | # t | #n t
      | t : e | t :: e

