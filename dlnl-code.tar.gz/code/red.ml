open Prelude
open Ast

exception Undefined
exception TpFail


module type Red_sig =  sig

  include Monad
  val subst : var -> tm -> tm -> tm t
  val rename : var -> var -> tm -> tm t
  val gensym : var -> var t
  val whred : tm -> tm t
  val fullred : tm -> tm t
  val conv : tm -> tm -> unit t
  val subst_gen : (var -> bool) -> (var -> bool) -> (var -> tm) -> tm -> tm t
  val rename_gen : (var -> bool) -> (var -> bool) -> (var -> var) -> tm -> tm t

end
type 'a varcomp = (var -> bool) -> 'a * (var -> bool)
module Redbase : Red_sig with type 'a t = 'a varcomp = struct

  include StateMon (struct type t = var -> bool end)

  let env_mem x f = f x

  let gensym v e =
   let split_inc v =
      let l = String.length v in
      let rec aux k =
        try
          let _ = int_of_string (String.sub v k 1) in
          aux (k-1)
        with _ -> String.sub v 0 (k + 1) in
      aux (l-1) in
   let rec gen v i =
      let w = v ^ (string_of_int i) in
      if env_mem w e then
           gen v (i+1)
      else w, e in
    if env_mem v e then
       let v = split_inc v in
       let v = if v = "" then "v" else v in
        gen v 0
     else
        v, e 

(*  let rec gensym v e =  if env_mem v e then
                          gensym (v ^ "'") e
                        else v, e *)

  let with_var x c f =
     let (a, _) = c (fun e -> x = e || f e) in (a, f)

  let drop_var x c e =  let (r,e) = c e in (r, fun y -> if x = y then false else e y)

  let drop_env f env = fst (f env)

  let rec subst x e (TIn e') =
   match e' with
   |Var y when x = y -> return e
   |Var x -> return (TIn (Var x))
   |Bnd (a, t) when a = x -> return (TIn e')
   |Bnd (a, t) when is_free_var a e -> with_var a 
      (gensym a >>= fun b -> rename a b (TIn t)
                >>= fun (TIn t) -> subst x e (TIn (Bnd (b, t))))
   |Bnd (a, t) -> with_var a (subst x e (TIn t)) >>= (fun (TIn b) -> return (TIn (Bnd (a, b))))
   |Annot (a, t) -> subst x e a >>= (fun a -> subst x e (TIn t)
                                >>= function TIn t -> return (TIn (Annot(a,t))))
   |t ->  fun env -> (TIn (map_tm' (fun a -> drop_env (subst x e a) env) t), env)
  and rename x y t = subst x (TIn (Var y)) t

  (* This is a parallel substitution:
  
     f -- f x is true when x is in the domain of the substitution
     f' -- f' x is true when x is in the codomain of the substitution
     g -- g x is the term to substitute for x 
  *)

  let rec subst_gen f f' g (TIn e') =
   match e' with
   |Var y when f y -> return (g y)
   |Var x -> return (TIn (Var x))
   |Bnd (a, t) when f a -> with_var a (subst_gen (fun x -> (not (x = a)) && (f x)) f'
                                     (fun x -> if x = a then TIn (Var a)
                                               else g x) (TIn t)) >>=
                           (function (TIn t') -> return (TIn (Bnd (a, t'))))
   |Bnd (a, t) when f' a -> with_var a 
      (gensym a >>= fun b -> rename a b (TIn t)
                >>= fun (TIn t) -> subst_gen f f' g (TIn (Bnd (b, t))))
   |Bnd (a, t) -> with_var a (subst_gen f f' g (TIn t)) >>= (fun (TIn b) -> return (TIn (Bnd (a, b))))
   |Annot (a, t) -> subst_gen f f' g a >>= (fun a -> subst_gen f f' g (TIn t)
                                >>= function TIn t -> return (TIn (Annot(a,t))))
   |t ->  fun env -> (TIn (map_tm' (fun a -> drop_env (subst_gen f f' g a) env) t), env)

  let rename_gen f f' g = subst_gen f f' (fun x -> TIn (Var (g x)))


  let (>>) a b = a >>= fun () -> b
  let ok = ()
  let drop_annot t = return (drop_annot t)
  let drop_surface_annot t = return (drop_surface_annot t)

  let rec whred (TIn t) : tm t =
    let ret x = return (TIn x) in
    let conv' a b e = try (conv a b >> return true) e with TpFail -> return false e in
    match t with
    (* beta laws *)
    Let (a, TIn (Bnd(x , e))) -> subst x a (TIn e) >>= whred
   |App (f, b) -> whred f >>= drop_surface_annot >>= (fun f ->
                  match f with
                  |TIn (Lam (TIn (Bnd (x, y)))) -> subst x b (TIn y) >>= whred
                  |TIn (Gen (TIn y)) -> whred (TIn y)
                  |_ -> ret t)
   |Fst p -> whred p >>=
              drop_surface_annot >>=
              (function (TIn (Pair (a,b))) | (TIn (WPair (a,b))) -> whred a | p -> ret t)
   |Snd p -> whred p >>=
              drop_surface_annot >>=
              (function (TIn (Pair (a,b))) | (TIn (WPair (a,b))) -> whred b | p -> ret t)
   |LetPair (p, TIn (Bnd (a, Bnd (b, e)))) ->  whred p >>=
              drop_surface_annot >>=
                  (function (TIn (Pair (t, t'))) ->
                                  subst b t' (TIn e) >>= fun e -> subst a t e >>= whred
                           |p -> ret (LetPair (p, TIn (Bnd (a, Bnd (b, e))))))
   |LetUnit (a, TIn (Bnd (x, e))) -> subst x (TIn Unit) (TIn e) >>= whred
   |LetF (p, TIn (Bnd (x, Bnd (a, t')))) -> whred p >>=
              drop_surface_annot >>=
              (function (TIn (F (e, t))) -> subst x e (TIn t') >>= fun t' -> subst a t t' >>= whred
                             |p -> ret (LetF (p, TIn (Bnd (x, Bnd (a, t'))))))
   |RunG p -> whred p >>=
              drop_surface_annot >>=
              (function (TIn (G a)) ->  whred a | p -> ret (RunG p))
   |J (ty, t', eq) -> whred eq >>=
              drop_surface_annot >>= (function (TIn Refl) -> whred t' | p -> ret t)
   |Natind (ty, t, TIn (Bnd(x, Bnd(y, t'))), k) -> whred k >>=
              drop_surface_annot >>=
                                   (function
                                     TIn Zero     -> whred t
                                    |TIn (Succ n) -> subst y (TIn (Natind (ty, t, TIn (Bnd (x, Bnd(y, t'))), n)))
                                                                        (TIn t') >>=
                                                     subst x n >>= whred
                                    | k           -> return (TIn (Natind (ty, t, TIn (Bnd(x, Bnd(y, t'))), k))))
   |Wind (ty, TIn (Bnd (a, Bnd (f, Bnd (r, t')))), w) -> whred w >>= 
              drop_surface_annot >>=
       (function TIn w ->
          match w with
           Sup (x, y) -> gensym "z" >>= fun z -> subst a x (TIn t') >>= subst f y >>= subst r
                         (TIn (Lam (TIn (Bnd (z, Wind(ty, TIn (Bnd (a, Bnd (f, Bnd (r, t')))), TIn (App (y, TIn (Var z))))))))) >>= whred
          | _ -> ret t)
   |Plusind (_, TIn (Bnd (x, cx)), TIn (Bnd (y, cy)), w) -> (whred w >>=
         drop_surface_annot >>= 
         function (TIn w) ->
          match w with
           Inl a -> subst x a (TIn cx)
          |Inr a -> subst y a (TIn cy)
          |_ -> ret t)
   |Unitind (_, c, x) -> whred x >>=
              drop_surface_annot >>=
                                      (function TIn Unit -> whred c
                                              |_ -> ret t)
   |LetPack (w, TIn (Bnd(x, Bnd(y, t)))) -> whred w >>= 
              drop_surface_annot >>=
                              (function TIn u ->
                                      match u with
                                       Pack (a, b) -> subst y b (TIn t) >>= whred
                                      | _ -> ret t)
   |LetT (e, TIn (Bnd (v, e'))) -> whred e >>=
             (function TIn Val u -> subst v u (TIn e') >>= whred
                     | _ -> ret t)
   (* some eta laws *)
   |WPair (t', t'')
   |Pair (t', t'') -> (whred t' >>=
              drop_surface_annot >>=
                         function TIn (Fst a) -> whred t'' >>=
                                                 (function TIn (Snd b) ->  conv' a b >>=
                                                             (function true -> whred a
                                                                      | _ -> ret t)
                                                         | _ -> ret t)
                                     | _ -> ret t)
   |Lam (TIn (Bnd (x, t'))) -> with_var x (whred (TIn t')) >>=
              drop_surface_annot >>=
                               (function TIn (App (f,  TIn (Var y))) when x = y -> whred f
                                        | _ -> ret t)
   |UShift (_, t) -> whred t
   |a -> ret a
  and conv t t' =
    let module D = Dist (MList (struct type t = tm end)) in
    fullred t  >>= function (TIn t)  ->
    fullred t' >>= function (TIn t') ->
    do_log ("Matching " ^ (string_of_tm (TIn t)) ^ " with " ^ (string_of_tm (TIn t')));
    match (t, t') with
     (Var x, Var y) -> if x = y then return ok
                       else raise TpFail
    |(Bnd(x, e), Bnd(y, e')) -> rename y x (TIn e') >>= fun t'' -> conv (TIn e) t''
(*  |(Squash _,_)
    |(_, Squash _)
    |(LetIrr (_,_),_)
    |(_,LetIrr (_,_)) -> return ok *)
    |_ -> let inv1 = map_tm' (const ()) in
          let inv2 k = D.flatten_tm' (map_tm' (fun x -> [x]) k) in
          if inv1 t <> inv1 t' then
             raise TpFail
          else
             List.fold_left2 (fun r a b -> conv a b >> r) (return ok) (inv2 t : tm list) (inv2 t')
  and fullred (t : tm) : tm t =
    drop_annot t >>= whred >>= function (TIn t) ->
      match t with
       Var x -> return (TIn (Var x))
      |Bnd (x, e) -> with_var x (fullred (TIn e)) >>= fun (TIn e) -> return (TIn (Bnd (x, e)))
      |_  -> fun env -> whred (TIn (map_tm' (fun x -> fst (fullred x env)) t)) env
end


module Red (M : sig include Monad
                    val lift : 'a varcomp -> 'a t end) : Red_sig with type 'a t = 'a M.t = struct
  include M

  let subst a b c = lift (Redbase.subst a b c)
  let subst_gen a b c d = lift (Redbase.subst_gen a b c d)
  let rename_gen a b c d = lift (Redbase.rename_gen a b c d)
  let rename a b c = lift (Redbase.rename a b c)
  let gensym a = lift (Redbase.gensym a)
  let whred a = lift (Redbase.whred a)
  let conv a b = lift (Redbase.conv a b)
  let fullred a = lift (Redbase.fullred a)

end
