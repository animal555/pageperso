open Prelude
open Ast
open Red

type usage = Zero | One | Aff

type ihyp = var * tm
type ienv = ihyp list
type lhyp  = var * (tm * usage)
type lenv = ienv * lhyp list
type 'a it = ienv -> 'a * ienv
type 'a lt = lenv -> 'a * lenv

module type PreITp_sig = sig
  type 'a t
  include Monad with type 'a t := 'a t
  type 'a s

  val forget : 'a s -> 'a t
  val with_var : var -> tm -> 'a t -> 'a t

  val subst : var -> tm -> tm -> tm t
  val rename : var -> var -> tm -> tm t
  val gensym : var -> var t
  val whred : tm -> tm t
  val fullred : tm -> tm t

  val conv  : tm -> tm -> unit t
  val drop_surface_annot : tm -> tm t
  val drop_annot : tm -> tm t

  val lookup : var -> tm t
  val ok : unit t

  val with_irr : 'a t -> 'a t

  val getctx : ienv t
  val run : 'a t -> 'a
end

module type PreLTp_sig = sig
  type 'a t
  include Monad with type 'a t := 'a t
  type 'a s

  val lift : 'a s -> 'a t
  val with_var  : var -> tm -> 'a t -> 'a t
  val with_ivar : var -> tm -> 'a t -> 'a t

  val subst : var -> tm -> tm -> tm t
  val rename : var -> var -> tm -> tm t
  val gensym : var -> var t
  val whred : tm -> tm t
  val fullred : tm -> tm t

  val join_us : usage -> usage -> usage
  val join : 'a t -> 'b t -> ('a * 'b) t

  val drop_surface_annot : tm -> tm t
  val drop_annot : tm -> tm t
  val conv  : tm -> tm -> unit t

  val lookup : var -> tm t
  val ok : unit t

  val with_irr : 'a t -> 'a t

  val getictx : ienv t
  val getctx : lhyp list t

  val affinize : unit t
end

module type UnfoldedITp_sig = sig
  include PreITp_sig

  val synth : (tm -> tm t) -> (tm -> tm -> unit t) -> tm -> tm t
  val check : (tm -> tm t) -> (tm -> tm -> unit t) -> tm -> tm -> unit t
end

module type LTp_sig = sig

  include PreLTp_sig

  val synth : tm -> tm t
  val check : tm -> tm -> unit t
end

module type UnfoldedLTp_sig = sig

  include PreLTp_sig

  val synth : (tm -> tm t) -> (tm -> tm -> unit t) -> tm -> tm t
  val check : (tm -> tm t) -> (tm -> tm -> unit t) -> tm -> tm -> unit t
end

module type ITp_sig = sig
  include PreITp_sig

  val synth : tm -> tm t
  val check : tm -> tm -> unit t
end

module FoldITp (I : UnfoldedITp_sig) : ITp_sig with type 'a s = 'a I.s
                                                and type 'a t = 'a I.t = struct
  include I
  let rec check a b = I.check synth check a b
      and synth a   = I.synth synth check a
end

module FoldLTp (I : UnfoldedLTp_sig) : LTp_sig with type 'a s = 'a I.s
                                                and type 'a t = 'a I.t = struct
  include I
  let rec check a b = I.check synth check a b
      and synth a   = I.synth synth check a
end

module PreITp (LTp : PreLTp_sig with type 'a t = 'a lt
                                and type 'a s = 'a it) : PreITp_sig with type 'a t = 'a it
                                                                   and type 'a s = 'a lt = struct

  let env_mem x l = List.mem x (fst (List.split l))

  include Red (struct type 'a t = 'a it
                      let (>>=) a f e = (uncurry f) (a e)
                      let return a env = (a, env)
                      let lift a env = let (r, _) = a (flip env_mem env) in
                                       (r, env) end)

  type 'a s = 'a lt

  let run t = fst (t [])

  let forget f env = let (a, (ienv, lenv)) = f (env, []) in
                       if List.exists (function (_,(_,One)) -> true | _ -> false) lenv then
                         (do_log "Unconsumed linear value!"; raise TpFail)
                       else
                         (a, ienv)
  let rec lookup x = function
    [] -> do_log ("Lookup of " ^ x ^ " failed"); raise TpFail
   |(a, t) :: tl when a = x -> let (u, tl') = whred t tl in
                               do_log ("Lookup, " ^ x ^ " : " ^ (string_of_tm t));
                               (u, (a, u) :: tl')
   | h :: t -> let (a, b) = lookup x t in (a, h :: b)

  let with_var v h f env = let (a, b) = f ((v,h) :: env) in (a, List.remove_assoc v b)

  let (>>) a b = a >>= fun () -> b
  let ok = return ()

  let rec drop_surface_annot (TIn t) =
    match t with
     Annot (t', _) -> drop_surface_annot t'
    |_ -> return (TIn t)

  let drop_annot t e = (Ast.drop_annot t, e)

  let with_irr c e = 
    let (a, _) = c
       (List.map (function (v, TIn (Irr x)) -> (v, x) | (v, ty) as a -> a) (List.map (fun (v, x) -> v, fst (drop_surface_annot x e)) e)) in
    (a, e)


  let getctx e = (e,e)
end

module ITp (PreITp : PreITp_sig) 
           (LTp : LTp_sig with type 'a t = 'a PreITp.s
                          and  type 'a s = 'a PreITp.t) : UnfoldedITp_sig with type 'a t = 'a PreITp.t
                                                                           and type 'a s = 'a PreITp.s
                                                                           and type 'a t = 'a LTp.s
                                                                           and type 'a s = 'a LTp.t = struct

  include PreITp
  module C = CompleteMon (PreITp)
  open C

  let check synth check (TIn t : tm) (v : tm) =
  let irr a = TIn (Irr a) in 
  drop_surface_annot v >>= whred >>= function (TIn t') -> 
  do_log ("Checking  " ^ (string_of_tm (TIn t)) ^ " against " ^ (string_of_tm (TIn t')));
   begin
    match t with
      Uni i
     |Lin i -> (match t' with
                 Uni j when i < j -> ok
                | _ -> raise TpFail)
     |W (a, TIn (Bnd (x, b)))
     |Pi (a, TIn (Bnd (x, b)))
     |Sigma (a, TIn (Bnd (x, b))) -> (match t' with
                                       Uni j -> with_var x a (check (TIn b) (TIn t')) >>
                                                check a (TIn t')
                                      | _ -> raise TpFail)
     |Plus (a, b) -> (match t' with
                      Uni j -> check b (TIn t') >> check a (TIn t')
                     | _ -> raise TpFail)
     |Eq (a, x, y) -> (match t' with
                        Uni j -> check a (TIn t') >> check x a >> check y a
                       | _    -> raise TpFail)
     |Gty a -> (match t' with
                 Uni j -> check a (TIn (Lin j))
                | _ -> raise TpFail)
     |Irr a -> (match t' with
                 Lin j
                |Uni j -> check a (TIn t')
                | _ -> raise TpFail)
     |Forall (a, TIn (Bnd (x, b)))
     |Exists (a, TIn (Bnd (x, b))) -> (match t' with
                                        Uni j
                                       |Lin j -> with_var x a (check (TIn b) (TIn t')) >>
                                                 check a (TIn (Uni j))
                                       | _ -> raise TpFail)
     |LPi (a, TIn (Bnd (x, b)))
     |Fty (a, TIn (Bnd (x, b))) -> (match t' with
                                     Lin j -> with_var x a (check (TIn b) (TIn t')) >>
                                              check a (TIn (Uni j))
                                    | _ -> raise TpFail)
     |Pointsto (x, y) ->(match t' with
                          Lin j -> check x (TIn Loc) >> check y (TIn (Uni j))
                         | _ -> raise TpFail)
     |T a   -> (match t' with
                 Lin _ -> check a (TIn t')
                |_ -> raise TpFail)
     |Tensor (a, b)
     |Lolli  (a, b)
     |With   (a, b) -> (match t' with
                         Lin _ -> check a (TIn t') >> check b (TIn t')
                        | _    -> raise TpFail)
     |Loc
     |Bot
     |Nat
     |Unitty  -> (match t' with
                   Uni _ -> ok
                  | _ -> raise TpFail)
     |Top
     |I    -> (match t' with
                Lin _ -> ok
               | _ -> raise TpFail)
     |Lam (TIn (Bnd (x,e))) -> (match t' with
                                 Pi (a, TIn (Bnd(y, b))) -> rename y x (TIn b) >>= (function b ->
                                                            with_var x a (check (TIn e) b))
                                |Forall (a, TIn (Bnd(y, b))) -> rename y x (TIn b) >>= (function b ->
                                                                with_var x (irr a) (check (TIn e) b))
                                |_ -> raise TpFail)
     |Pair (e, e')    -> (match t' with
                          Sigma (a, TIn (Bnd (z, b))) -> check e a >>
                                                         subst z e (TIn b) >>= (function b' ->
                                                         check e' b')
                         |Exists (a, TIn (Bnd (z, b))) -> check e a >>
                                                          with_var z a (check e' (TIn b))
                         |_ -> raise TpFail)
     (* weak eliminator for sigma types *)
     |LetPair (e, (TIn (Bnd (a, Bnd (b, e'))))) -> synth e >>= (function (TIn te) ->
                                                   match te with
                                                   |Sigma  (ta, TIn (Bnd (x, tb))) -> with_var a ta ((subst x (TIn (Var a)) (TIn tb) >>= fun tb -> with_var b tb (check (TIn e') (TIn t'))))
                                                   |Exists (ta, TIn (Bnd (x, tb))) -> with_var a (TIn (Irr ta)) ((subst x (TIn (Var a)) (TIn tb) >>= fun tb -> with_var b tb (check (TIn e') (TIn t'))))
                                                   |_ -> raise TpFail)
     |Inl e           -> (match t' with
                          |Plus (a, _) -> check e a
                          |_ -> raise TpFail)
     |Inr e           -> (match t' with
                          |Plus (_, a) -> check e a
                          |_ -> raise TpFail)
     |G a             -> (match t' with
                           Gty ty -> forget (LTp.check a ty)
                          |_ -> raise TpFail)
     |Botind a        -> check a (TIn Bot)
     |Sup (e, e')     -> (match t' with
                           W (a, TIn (Bnd (x, b))) -> check e a >> subst x e (TIn b) >>= fun b -> 
                                                                   check e' (TIn (Pi (b, TIn (Bnd ("_", t')))))
                          |_ -> raise TpFail)
     |Annot(t, _)     -> check t (TIn t')   (* maybe we should check that second component is a type... *)
     |Refl            -> (match t' with
                           Eq (a, x, y) -> check x a >> check y a >> conv x y
                          |_ -> raise TpFail)
     |Let (a, TIn (Bnd (x, e))) -> subst x a (TIn e) >>= flip check (TIn t')
     |Squash a        -> (match t' with Irr o -> with_irr (check a o) | _ -> raise TpFail)
     |UShift (i, t)   -> check t (ushift (-i) (TIn t'))
     |_               -> (match t' with
                          |Uni i -> synth (TIn t) >>= (function (TIn t'ty) -> match t'ty with
                                                                                Uni j when i >= j  -> ok
                                                                               | _ -> raise TpFail)
                          |Lin i -> synth (TIn t) >>= (function (TIn t'ty) -> match t'ty with
                                                                                Lin j when i >= j  -> ok
                                                                               | _ -> raise TpFail)
                          |Any -> ok (* this allows terms with free variables to typecheck
                                        not sure if I should change it *)
                          | _ -> synth (TIn t) >>= function t'' -> conv (TIn t') t'')
    end
 
 let synth synth check (TIn t : tm) : tm t =
 do_log ("Synthesis of " ^ (string_of_tm (TIn t)));
    begin
      match t with
      Var t -> lookup t
     |Uni i -> return (TIn (Uni (i+1)))
     |Lin i -> return (TIn (Uni (i+1)))
     |W (a , TIn (Bnd (z, b)))
     |Pi (a , TIn (Bnd (z, b)))
     |Sigma (a, TIn (Bnd (z, b))) -> synth a >>= (function (TIn ta) -> 
                                     with_var z a (synth (TIn b)) >>= function (TIn tb) ->
                                    match (ta, tb) with
                                     (Uni i, Uni j) -> return (TIn (Uni (max i j)))
                                    |_ -> raise TpFail)
     |Plus(a, b ) -> synth a >>= (function (TIn ta) ->
                     synth b >>=  function (TIn tb) ->
                     match (ta, tb) with
                      (Uni i, Uni j) -> return (TIn (Uni (max i j)))
                     |_ -> raise TpFail)
     |With (a,b)
     |Tensor (a , b)
     |Lolli (a, b) -> synth a >>= (function (TIn ta) ->
                      synth b >>=  function (TIn tb) -> 
                      match (ta, tb) with
                       (Lin i, Lin j) -> return (TIn (Lin (max i j)))
                      |_ -> raise TpFail)
     |Pointsto (a, b) -> check a (TIn Loc) >> synth b >>= (function (TIn tb) ->
                         match tb with
                          Uni i -> return (TIn (Lin i))
                         |_ -> raise TpFail)
     |T a
     |Irr a -> synth a >>= (function TIn (Lin o) -> return (TIn (Lin o)) 
                                    |TIn (Uni o) -> return (TIn (Uni o))
                                    | _ -> raise TpFail)
     |Fty (a, TIn (Bnd (z, b))) 
     |LPi (a, TIn (Bnd (z, b)))   -> synth a >>= (function (TIn ta) ->
                                     with_var z a (synth (TIn b)) >>=  function (TIn tb) ->
                                     match (ta, tb) with
                                     (Uni i, Lin j) -> return (TIn (Lin (max i j)))
                                    |_ -> raise TpFail)
     |Forall (a, TIn (Bnd (z, b))) 
     |Exists (a, TIn (Bnd (z, b))) ->synth a >>= (function (TIn ta) ->
                                     with_var z a (synth (TIn b)) >>=  function (TIn tb) ->
                                     match (ta, tb) with
                                     (Uni i, Lin j) -> return (TIn (Lin (max i j)))
                                    |(Uni i, Uni j) -> return (TIn (Uni (max i j))) 
                                    |_ -> raise TpFail)
     |Bot
     |Nat
     |Loc
     |Unitty       -> return (TIn (Uni 0))
     |Top
     |I -> return (TIn (Lin 0))
     |Fst a -> synth a >>= (function (TIn ta) ->
                            match ta with
                             Sigma (a', TIn (Bnd (z, b'))) -> return a'
                            |_ -> raise TpFail)
     |Snd a -> synth a >>= (function (TIn ta) ->
                            match ta with
                             Sigma (a', TIn (Bnd (z, b'))) -> subst z (TIn (Fst a)) (TIn b') >>= whred
                            |_ -> raise TpFail)
     |Eq (a, e, e') -> synth a >>= (function (TIn (Uni i)) ->
                                               check e a >> check e' a >> return (TIn (Uni i))
                                                       | _ -> raise TpFail)
     |Gty a        -> synth a >>= (function (TIn ta) ->
                      match ta with
                       Lin i -> return (TIn (Uni i))
                      |_ -> raise TpFail)
     |Unit         -> return (TIn Unitty)
     |App (e, e')  -> synth e >>= (function (TIn te) ->
                      match te with
                       Pi (a, TIn (Bnd (z, b))) -> check e' a >>
                                                   subst z e' (TIn b) >>= whred
                      |Forall (a, TIn (Bnd (z, b))) -> with_irr (check e' a) >>
                                                       subst z e' (TIn b) >>= whred
                      |_ -> raise TpFail)
     |Annot (e, t) -> check e (TIn t) >> return (TIn t)
     |J(TIn (Bnd (x, Bnd(y, Bnd (p, ty)))), t, e)  -> synth e >>= (function
                                                       TIn (Eq (a, x', y')) -> rename y x (TIn ty) >>=
                                                                               subst x x' >>=
                                                                               subst p (TIn Refl) >>=
                                                                               check t >>
                                                                               subst x x' (TIn ty) >>=
                                                                               subst y y' >>=
                                                                               subst p e
                                                      | _ -> raise TpFail)
     |Zero   -> return (TIn Nat)
     |Succ e    -> check e (TIn Nat) >> return (TIn Nat)
     |Natind (TIn (Bnd (z, ty)), t, TIn (Bnd (x, Bnd(h, t'))), n) -> check n (TIn Nat) >>
                                                             with_irr (with_var z (TIn Nat) (synth (TIn ty))) >>=
                                                             (function TIn (Uni _) ->
                                                                (subst z (TIn Zero) (TIn ty) >>= fun tty ->
                                                                 check t tty) >>
                                                                (subst z (TIn (Succ (TIn (Var x))))
                                                                       (TIn ty) >>= fun t'ty ->
                                                                 subst z (TIn (Var x)) (TIn ty) >>= fun t''ty ->
                                                                 with_var x (TIn Nat)
                                                                 (with_var h t''ty
                                                                         (check (TIn t') t'ty))) >>
                                                                subst z n (TIn ty) >>= whred
                                                                      | _ -> raise TpFail)
     |Wind (TIn (Bnd (x, ty)), TIn (Bnd (a, Bnd (b, Bnd (r, t)))), w) ->
              synth w >>= (function (TIn wty) -> match wty with
                                            W (aty, TIn (Bnd (y, bty))) -> (gensym "z" >>= fun z -> gensym "o" >>= fun o ->
                                                                            rename y a (TIn bty) >>= fun bty ->
                                                                            subst x (TIn (App (TIn (Var b), TIn (Var z)))) (TIn ty) >>= function (TIn ty') ->
                                                                            subst x (TIn (Sup (TIn (Var a), TIn (Var b)))) (TIn ty) >>= fun ty'' ->
                                                                            List.fold_right (uncurry with_var)
                                                                              [a, aty ; b, TIn (Pi (bty, TIn ( Bnd(o, wty))));
                                                                               r, TIn (Pi (bty, TIn (Bnd (z, ty'))))] (check (TIn t) ty'') >> subst x w (TIn ty))
                                           |_ -> raise TpFail)
     |Plusind(TIn (Bnd (x, ty)), TIn (Bnd (a, ca)), TIn (Bnd (b, cb)), w) ->
        synth w >>= (function (TIn wty) -> match wty with
                                            Plus (ta, tb) -> with_var a ta (subst x (TIn (Inl (TIn (Var a)))) (TIn ty) >>= check (TIn ca)) >>
                                                             with_var b tb (subst x (TIn (Inr (TIn (Var b)))) (TIn ty) >>= check (TIn cb)) >>
                                                             subst x w (TIn ty)
                                           | _ -> raise TpFail)
     |Unitind(TIn (Bnd (x, ty)), t, u) -> check u (TIn Unitty) >> subst x (TIn Unit) (TIn ty) >>= check t >> subst x u (TIn ty)
     |Squash e -> with_irr (synth e) >>= fun a -> return (TIn (Squash a))
     |G e -> forget (LTp.synth e) >>= fun ty -> return (TIn (G ty))
     |UShift (i, t) -> synth t >>= fun r -> return (ushift i r)
     |_ -> raise TpFail
    end >>= drop_surface_annot >>= fullred
end

module PreLTp (ITp : PreITp_sig with type 'a t = 'a it
                                and type 'a s = 'a lt) : PreLTp_sig with type 'a t = 'a lt
                                                                     and type 'a s = 'a it = struct

  type 'a s = 'a it
  let lift f (ienv, lenv) = let (a, ienv') = f ienv in
                            (a, (ienv, lenv))

  let join_us a b = match (a,b) with
                   (Aff, b) -> b
                 | (a, Aff) -> a
                 | _ -> if a = b then a else raise Undefined

  let rec env_mem x l =
    let f a = List.mem x (fst (List.split (a l))) in
    f fst || f snd

  let return a env = (a, env)
  let (>>=) a f e = (uncurry f) (a e)

  include Red (struct type 'a t = 'a lt
                      let (>>=) = (>>=)
                      let return = return
                      let lift a env = let (r, _) = a (flip env_mem env) in
                                       (r, env) end)

  let drop_annot t e = (Ast.drop_annot t, e)

  let with_irr c (e, e') = 
    let (a, (_, e'')) = c ((List.map (function (v, TIn (Irr x)) -> (v, x) | (v, ty) as a -> a) e), e') in
    (a, (e, e''))

  let with_ivar v h f (ienv, lenv) =
    let r = List.remove_assoc v in
    let (a, (ienv, lenv)) = f ((v, h) :: (r ienv), lenv) in
    (a, (r ienv, lenv))

  let with_var v h f (ienv, lenv) =
    let r = List.remove_assoc v in
    let (a, (ienv, lenv)) = f (ienv, (v, (h, One)) :: (r lenv)) in
    (try
      if snd (List.assoc v lenv) = One then
         raise TpFail
      else ()
    with Not_found -> ()) ;
    (a, (ienv, r lenv))


  let join a b env =
    let (a, (ienv, lenva)) = a env in
    let (b, (_   , lenvb)) = b env in
    let sort = List.sort (fun (x,_) (y,_) -> compare x y) in
    let rec merge l l' : 'a list = match (l, l') with
       ((h,(th,u)) :: t, (h',(th',u')) :: t') ->
        let b = compare h h' in
         if b < 0 then merge t l'
         else if b > 0 then merge l t'
         else
           let u = try join_us u u' with Undefined -> raise TpFail in
            (h, (th, u)) :: (merge t t')
      |([], l) -> l
      |(l, []) -> l
    in
    ((a, b), (ienv,
     List.filter (function (_,(_,Zero)) -> false | _ -> true)
       (merge (sort lenva) (sort lenvb))))

  let affinize : unit t = fun (ienv, lenv) ->
      ((), (ienv, List.map (fun (v, (h, u)) -> (v, (h, match u with
                                                        Zero -> Zero
                                                       | _ -> Aff))) lenv))

  let drop_env f env = fst (f env)

  let (>>) a b = a >>= fun () -> b
  let ok = return ()

  let lookup x (ienv, lenv) =
    try
      match List.assoc x lenv with
      |(a, Zero) -> do_log ("Linear lookup of " ^ x ^ " failed"); raise TpFail
      |(a, _) -> let a = fst (fullred a (ienv, lenv)) in
                 do_log ("Linear lookup, " ^ x ^ " : " ^ (string_of_tm a));
                 (a, (ienv, List.remove_assoc x lenv))
    with Not_found -> raise TpFail

  let rec drop_surface_annot (TIn t) =
    match t with
     Annot (t', _) -> drop_surface_annot t'
    |_ -> return (TIn t)
  let getctx (e, e') = (e', (e, e'))
  let getictx (e, e') = (e, (e, e'))
end

module LTp (PreLTp : PreLTp_sig)
           (ITp : ITp_sig with type 'a t = 'a PreLTp.s
                           and type 'a s = 'a PreLTp.t) : UnfoldedLTp_sig with type 'a t = 'a PreLTp.t
                                                                           and type 'a s = 'a PreLTp.s = struct

  include PreLTp
  module M = CompleteMon (PreLTp)
  open M

  let join = PreLTp.join

  let check synth check (TIn t) t' : unit t =
  let irr x = TIn (Irr x) in
      drop_surface_annot t' >>= whred >>= function (TIn t') ->
      do_log ("Checking  " ^ (string_of_tm (TIn t)) ^ " against " ^ (string_of_tm (TIn t')));
      match t with
      |Lam (TIn (Bnd (z, e))) -> (match t' with
                                 LPi (a, TIn( Bnd(y, b))) -> rename y z (TIn b) >>= fun b ->
                                                             with_ivar z a (check (TIn e) b)
                                |Forall (a, TIn( Bnd(y, b))) -> rename y z (TIn b) >>= fun b ->
                                                             with_ivar z (irr a) (check (TIn e) b)
                                |Lolli (a, b) -> with_var z a (check (TIn e) b)
                                |_ -> raise TpFail)
      |Gen (TIn (Bnd (z, e))) -> (match t' with
                                  Forall (a, TIn( Bnd(y, b))) -> rename y z (TIn b) >>= fun b ->
                                                                 with_ivar z (irr a) (check (TIn e) b)
                                 |_ -> raise TpFail)
      |Pair (e, e') -> (match t' with
                        Tensor (a, b) -> check e a >> check e' b
                       |_ -> raise TpFail)
      |Pack (e, e') ->(match t' with
                        Exists (a, TIn (Bnd (y, b))) ->
                                  with_irr (lift (ITp.check e a)) >>
                                  subst y e (TIn b) >>= fun b ->
                                  check e' b
                       | _ -> raise TpFail)
      |F (e, e') -> (match t' with
                      Fty (a, TIn (Bnd (x, b))) -> lift (ITp.check e a) >> subst x e (TIn b) >>= check e'
                     |_ -> raise TpFail)
      |WPair (e, e') -> (match t' with
                          With (a, b) -> join (check e a) (check e' b) >>= fun ((),()) -> ok
                         |_ -> raise TpFail)
      |LetF (e, (TIn (Bnd (x, Bnd (a, e'))))) -> synth e >>= (function (TIn t'') ->
                                                 match t'' with
                                                  Fty (tx, TIn Bnd(z, ta)) -> rename z x (TIn ta) >>= fun ta ->
                                                                          with_var a ta (with_ivar x tx (check (TIn e') (TIn t')))
                                                 |_ -> raise TpFail)
      |LetUnit (e, e') -> check e (TIn I) >> check e' (TIn t')
      |Unit -> (match t' with I -> ok | Top -> affinize >> ok | _ -> raise TpFail)
      |LetPair (e, (TIn (Bnd (a, Bnd (b, e'))))) -> synth e >>= (function (TIn te) ->
                                                    match te with
                                                    |Tensor (ta, tb) -> with_var a ta (with_var b tb (check (TIn e') (TIn t')))
                                                    |_ -> raise TpFail)
      |LetIrr (e, TIn (Bnd(x, e'))) -> (match t' with
                                   Irr b -> synth e >>= (function TIn te ->
                                            match te with
                                            Irr a -> with_var x a (check (TIn e') (irr b))
                                           |_ -> raise TpFail)
                                  | _ -> raise TpFail)
      |LetPack (e, (TIn (Bnd (x, Bnd (a, e'))))) ->
         synth e >>= (function (TIn t'') ->
         match t'' with
          Exists (tx, TIn (Bnd(b, ta))) -> rename b x (TIn ta) >>= fun ta ->
                                     with_ivar x (irr tx)
                                        (with_var a ta (check (TIn e') (TIn t')))
         |_ -> raise TpFail)
      |LetIrrPair (e, (TIn (Bnd (a, Bnd (b, e'))))) ->
          synth e >>= (function (TIn te) ->
          match te with
         |Irr (TIn (Tensor (ta, tb))) -> with_var b (irr tb) (with_var a (irr ta) (check (TIn e') (TIn t')))
         |_ -> raise TpFail)
      |LetIrrUnit (e, e') -> check e (TIn (Irr (TIn I))) >> check e' (TIn t')
      |Squash e -> (match t' with Irr o -> with_irr (check e o) | _ -> raise TpFail)
      |Val e -> (match t' with T o -> check e o | _ -> raise TpFail)
      |LetT (e, TIn (Bnd(x, e'))) -> (match t' with
                                 T o -> synth e >>= (function TIn te ->
                                        match te with
                                         T i -> with_var x i (check (TIn e') (TIn (T o)))
                                        | _  -> raise TpFail)
                                | _ -> raise TpFail)
      |New e -> (fullred (TIn t') >>= function (TIn t') -> match t' with
                 T (TIn (Fty (TIn Loc, TIn (Bnd(x, Irr (TIn (Pointsto (TIn (Var y), a)))))))) when x = y ->
                   lift ((*ITp.with_irr*) (ITp.check e a))
                |_ -> raise TpFail)
      |LetGet(l, c, TIn (Bnd(x, Bnd(a, e)))) ->
          lift (ITp.check l (TIn Loc)) >> synth c >>= (function TIn t ->
               match t with
                Irr (TIn (Pointsto (l', tx))) -> conv l l' >> with_ivar x tx (with_var a (TIn t) (check (TIn e) (TIn t')))
               | _ -> raise TpFail)
      |Let (a, TIn (Bnd (x, e))) -> subst x a (TIn e) >>= flip check (TIn t')
      |Botind a               -> lift (ITp.check a (TIn Bot))
      |UShift (i, t) -> check t (ushift (-i) (TIn t'))
      |_               -> (match t' with
                            Any -> ok
                          | _ -> synth (TIn t) >>= conv (TIn t'))

 let synth synth check (TIn t) =
    do_log ("Synthesis of " ^ (string_of_tm (TIn t)));
    match t with
    |Var x -> lookup x
    |Annot (e, b) -> check e (TIn b) >> return (TIn b)
    |App (e, e') -> synth e >>= (function (TIn te) ->
                    match te with
                    |Lolli (a, b) -> check e' a >> return b
                    |Forall (a, (TIn (Bnd (x, e'')))) ->
                         (lift (ITp.with_irr (ITp.check e' a))) >>
                                                         subst x e' (TIn e'') >>= whred
                    |LPi (a, (TIn (Bnd (x, e'')))) -> lift (ITp.check e' a) >> subst x e' (TIn e'') >>= whred
                    |_ -> raise TpFail)
(*  |Pair (a, b) -> synth a >>= (fun ta -> synth b >>= fun tb -> TIn (Tensor (a,b))) *)
(*  |LetPair (e, (TIn (Bnd (a, Bnd (b, e'))))) -> synth e >>= (function (TIn te) ->*)
(*                                                match te with*)
(*                                                |Tensor (ta, tb) -> with_var a ta (with_var b tb (synth e'))*)
(*                                                |_ -> raise TpFail)*)
    |Unit -> return (TIn I)
(*  |LetUnit (e, Bnd (x, e')) -> check e I >> subst x (TIn Unit) e' >>= synth *)
(*  |WPair (a, b) -> join (synth a) (synth b) >>= (fun (a, b) -> With (a, b)) *)
    |Fst e -> synth e >>= (function (TIn te) ->
                match te with
                 With (a, b) -> return a
                |_ -> raise TpFail)
    |Snd e -> synth e >>= (function (TIn te) ->
                match te with
                 With (a, b) -> return b
                |_ -> raise TpFail)
(*  |LetF (e, (TIn (Bnd (x, Bnd (a, e'))))) -> synth e >>= (function (TIn t') ->
                                               match t' with
                                                F (tx, ta) -> with_ivar x tx (with_var a ta (synth e'))
                                               |_ -> raise TpFail) *)
    |RunG e -> lift (ITp.synth e) >>= (function (TIn te) ->
               match te with
                Gty a -> return a
               |_ -> raise TpFail)
    |Assign (e, e', e'') -> lift (ITp.check e (TIn Loc)) >> synth e' >>= fullred >>= (function TIn t ->
                              match t with
                               Irr (TIn (Pointsto (l, tx))) -> conv l e >> (*with_irr*) (lift (ITp.synth e'')) >>= fun ty ->
                                                       return (TIn (T (TIn (Irr (TIn (Pointsto (l, ty)))))))
                             | _ -> raise TpFail)
    |LetGet(l, c, TIn (Bnd(x, Bnd(a, e)))) ->
          lift (ITp.check l (TIn Loc)) >> synth c >>= (function TIn t ->
               match t with
                Irr (TIn (Pointsto (l', tx))) -> conv l l' >> with_ivar x tx (with_var a (TIn t) (synth (TIn e)))
               | _ -> raise TpFail)
    |Free (t, t') -> lift (ITp.check t (TIn Loc)) >>
                     synth t' >>= (function (TIn ty) -> match ty with
                                                  Irr (TIn (Pointsto (l', tx))) -> conv t l' >> 
                                                                                   return (TIn (T (TIn I)))
                                                 | _ -> raise TpFail)
    |New t -> lift (ITp.synth t) >>= (fun ty ->
           gensym "l" >>= (fun l  -> 
          return (TIn (T (TIn (Fty (TIn Loc, TIn  (Bnd (l, Irr (TIn (Pointsto (TIn (Var l), ty))))))))))))
    |Squash e -> with_irr (synth e) >>= fun a -> return (TIn (Squash a))
    (* Case analysis for intuitionistic types *)
    |Plusind(TIn (Bnd (x, ty)), TIn (Bnd (a, ca)), TIn (Bnd (b, cb)), w) ->
        lift (ITp.synth w) >>= (function (TIn wty) -> match wty with
                                            Plus (ta, tb) -> join
                                                             (with_ivar a ta (subst x (TIn (Inl (TIn (Var a)))) (TIn ty) >>= check (TIn ca))) 
                                                             (with_ivar b tb (subst x (TIn (Inr (TIn (Var b)))) (TIn ty) >>= check (TIn cb))) >>
                                                             subst x w (TIn ty)
                                           | _ -> raise TpFail)
    |Wind (TIn (Bnd (x, ty)), TIn (Bnd (a, Bnd (b, Bnd (r, t)))), w) ->
             lift (ITp.synth w) >>= (function (TIn wty) -> match wty with
                                           W (aty, TIn (Bnd (y, bty))) -> (gensym "z" >>= fun z -> gensym "o" >>= fun o ->
                                                                           rename y a (TIn bty) >>= fun bty ->
                                                                           subst x (TIn (Sup (TIn (Var a), TIn (Var b)))) (TIn ty) >>= fun ty'' ->
                                                                           List.fold_right (uncurry with_ivar)
                                                                             [a, aty ; b, TIn (Pi (bty, TIn ( Bnd(o, wty))));
                                                                              r, TIn Any] (lift (ITp.check (TIn t) ty'')) >> subst x w (TIn ty))
                                          |_ -> raise TpFail)
    |Natind (TIn (Bnd (z, ty)), t, TIn (Bnd (x, Bnd(h, t'))), n) -> lift (ITp.check n (TIn Nat)) >>
                                                            lift (ITp.with_irr (ITp.with_var z (TIn Nat) (ITp.synth (TIn ty)))) >>=
                                                            (function TIn (Lin _) ->
                                                               join
                                                               (subst z (TIn Zero) (TIn ty) >>= fun tty ->
                                                                check t tty)
                                                               (subst z (TIn (Succ (TIn (Var x))))
                                                                      (TIn ty) >>= fun t'ty ->
                                                                with_var x (TIn Nat)
                                                                (with_var h (TIn Any)
                                                                        (check (TIn t') t'ty))) >>
                                                               subst z n (TIn ty) >>= whred
                                                                     | _ -> raise TpFail)
    |Unitind(TIn (Bnd (x, ty)), t, u) -> lift (ITp.check u (TIn Unitty)) >> subst x (TIn Unit) (TIn ty) >>= check t >> subst x u (TIn ty)
    |J(TIn (Bnd (x, Bnd(y, Bnd (p, ty)))), t, e)  -> lift (ITp.synth e) >>= (function
                                                       TIn (Eq (a, x', y')) -> rename y x (TIn ty) >>=
                                                                               subst x x' >>=
                                                                               subst p (TIn Refl) >>=
                                                                               check t >>
                                                                               subst x x' (TIn ty) >>=
                                                                               subst y y' >>=
                                                                               subst p e
                                                      | _ -> raise TpFail)
    |UShift (i, t) -> synth t >>= fun r -> return (ushift i r)
    |_ -> raise TpFail
end



module rec PreITpImpl : PreITp_sig with type 'a t = 'a it
                             and type 'a s = 'a lt = PreITp (PreLTpImpl)
and PreLTpImpl : PreLTp_sig with type 'a t = 'a lt
                             and type 'a s = 'a it = PreLTp (PreITpImpl)
module rec ITpchk : ITp_sig with type 'a t = 'a it
                             and type 'a s = 'a lt = FoldITp (ITp (PreITpImpl) (LTpchk))
and LTpchk : LTp_sig with type 'a t = 'a lt
                     and  type 'a s = 'a it = FoldLTp (LTp (PreLTpImpl) (ITpchk))
