open Prelude
open Ast
open Red
open Parser
open Tpchk

let btree = ref false
let stree = ref ""

let m = Arg.parse ["-d", Arg.Unit (fun () -> show_debug := false), "Hide typing trace.";
                    "-a", Arg.Unit (fun () -> show_annot := true),  "Show type annotations";
                    "--tree", Arg.String (fun s -> btree := true; stree := s), "Marshall a derivation tree"]
         ignore "";
         if !btree then
         (
           if !stree = "" then
             stree := "tree.out";
           (module (Deriv.ITptreechk (struct let v = !stree end)) : ITp_sig))
         else
           (module ITpchk : ITp_sig)
module I = (val m : ITp_sig)

module type PreTop_sig = sig
  include Monad
  val string_of_env : string t
  val is_fresh : var -> bool t
  val gensym : var -> var t
  val rename : var -> var -> unit t
  val with_ax : var -> tm -> 'a t -> 'a t
  val with_def : var -> tm -> tm -> 'a t -> 'a t
  val drop_def : tm -> tm t
  val lift : 'a I.t -> 'a t
  val lift' : 'a Redbase.t -> 'a t
  val run : 'a t -> 'a
  val catchall : 'a t -> 'a option t
  val restart : unit t
  val instantiate : var -> tm -> bool t
  val generalize : var -> bool t
  val forget : var -> unit t
  val is_ax : var -> bool t
  val check : tm -> tm -> bool t
  val synth : tm -> tm option t
end

module PreTop (P : PreTop_sig) : sig include PreTop_sig
                                     val with_prefix : string -> 'a t -> 'a t end = struct
  module VSet = Set.Make (struct type t = var let compare = compare end)
  type prefix = string * VSet.t
  include StateMonTrans (struct type t = prefix end) (P)
  let (>>) a b = a >>= fun () -> b
  let lift' c = lift (P.lift' c)
  let add_prefix_var v (s,e) = setstate (s, VSet.add v e) (s,e)
  let prefix s : string t = getstate >>= function ("", _) -> return  s | (pre, _) -> return (pre ^ "_" ^ s)
  let add_prefix_var v = add_prefix_var v >> prefix v
  let string_of_env = lift P.string_of_env
  let rename a b = prefix a >>= fun a -> prefix b >>= fun b -> lift (P.rename a b)
  let gensym v = lift (P.gensym v)
  let is_fresh v = prefix v >>= fun v -> lift (P.is_fresh v)
  let rename_gen f f' g t = lift' (Redbase.rename_gen f f' g t)
  let tm_trans (t : tm) : tm t = getstate >>= fun (pre,e) ->
                                  let f = flip VSet.mem e in
                                   rename_gen f (fun x -> let prelen = String.length pre in
                                                          if String.length x < prelen then false
                                                          else
                                                          let cpre = String.sub x 0 prelen in
                                                            cpre = pre && prelen <> 0 (*a bit too agressive*) )
                                                                            (function s -> pre ^ (match pre with "" -> "" | _ -> "_") ^ s) t
  let with_ax a b c = getstate >>= fun (s,_) -> return s >>= fun pre ->
                      add_prefix_var a >>= fun a -> tm_trans b >>= fun b ->
                      getstate >>= fun st -> lift (P.with_ax a b (c st)) >>=
                      fun (a,_) -> return a
  let with_def a b c d = getstate >>= fun (s,_) -> return s >>= fun pre ->
                         add_prefix_var a>>= fun a -> tm_trans b >>= fun b ->
                         getstate >>= fun st -> lift (P.with_def a b c (d st)) >>=
                         fun (a,_) -> return a
  let check t t' = tm_trans t >>= fun t -> tm_trans t' >>= fun t' -> lift (P.check t t')
  let synth t = tm_trans t >>= fun t -> lift (P.synth t)
  let with_prefix s c q = P.(>>=) (c (s, VSet.empty)) (fun (a,_) -> P.return (a, q))
  let drop_def a = lift (P.drop_def a)
  let run c = fst (P.run (c ("", VSet.empty)))
  let catchall c =
      fun e -> try P.(>>=) (P.catchall (c e)) (function Some (a,e) -> P.return (Some a, e)
                                                       |None       -> P.return (None, e))
               with TpFail -> P.return (None, e)
  let instantiate a b = prefix a >>= fun a -> tm_trans b >>= fun b -> lift (P.instantiate a b)
  let generalize a = prefix a >>= fun a -> lift (P.generalize a)
  let forget a = prefix a >>= fun a -> lift (P.forget a)
  let is_ax v = prefix v >>= fun v -> lift (P.is_ax v)
  let restart = lift P.restart
  let lift t = lift (P.lift t)
end

module PreTopbase : PreTop_sig = struct

type hyp = Hax of var * tm | Hdef of var  * (tm * tm)

include StateMon (struct type t = hyp list end)
let (>>) a b = a >>= (const b)

let run a = fst (a [])

let restart e = ((),[])

let rec list_reduce ( * ) e = function [] -> e | x :: t -> x * (list_reduce ( * ) e t)

let string_of_env e =
  let sotm = string_of_tm in
  let (^^) s s' = s ^ "\n" ^ s' in
  (list_reduce (^^) ""
     (List.map (function Hdef (v, (t, ty)) -> 
                   "val " ^ v ^ " := " ^(sotm t) ^ ";"
                       | Hax (v, t) -> "  " ^ v ^ " :: " ^(sotm t) ^ ";") e))
let string_of_env e = string_of_env e, e

let rec is_fresh_aux v = function [] -> true
                                | Hdef (h, (_,_)) :: _
                                | Hax (h,_) :: _ when h = v -> false
                                | _ :: t -> is_fresh_aux v t

let is_fresh v e = (is_fresh_aux v e, e)
let rec gensym v = is_fresh v >>= function true -> return v | false -> gensym (v ^ "'")
let rec rename a b e =
   let r t = fst (Redbase.rename a b t (const false)) in
   let rec aux = function [] -> []
                         |Hdef (v, (t,ty)) :: tl ->  Hdef(v, (r t, r ty)) :: (aux tl)
                         |Hax  (v, ty) :: tl -> Hax (v, r ty) :: (aux tl) in
   let rec auxskip = function [] -> []
                             |(Hdef (v, t) :: tl) when v = a -> Hdef(b, t) :: (aux tl)
                             |(Hax (v, t) :: tl) when v = a -> Hax (b, t) :: (aux tl)
                             | u :: tl -> u :: (auxskip tl) in
   (), auxskip e
let rec ax  = function [] -> []
                     | (Hax (v,t)) :: tl -> (v,t) :: ax tl
                     | _ :: tl -> ax tl
let rec def = function [] -> [] 
                     | (Hdef (v,(t,t'))) :: tl -> (v,(t,t')) :: def tl
                     | _ :: tl -> def tl
let with_ax v tm c e = c (e @ [Hax (v, tm)] )
let with_def v t (TIn ty) c e = c (e @ [Hdef (v, (TIn (Annot (t,ty)), TIn ty))])
let drop_def (t : tm) (e : hyp list) : tm * hyp list = (fst 
                       (List.fold_right 
                           (fun (v, (tm, _)) t -> Redbase.(>>=) t (Redbase.subst v tm))
                                                       (def e) (Redbase.return t) 
                                                               (fun x -> not (fst (is_fresh x e)))), (e : hyp list))
let getrawax e = (List.map (fun (v,t) -> v, fst (drop_def t e)) (ax e), e)
let getrawdef e = (List.map (fun (v,(t,t')) -> v, (fst (drop_def t e), fst (drop_def t' e))) (def e), e)
let lift c e = let e' = fst (getrawax e)  in
               let a = I.run (List.fold_right (uncurry I.with_var) e' c) in (a, e)
let lift' c = getstate >>= fun e -> return (fst (c (fun v -> is_fresh_aux v e)))
let catchall f x = try let (a, b) = f x in (Some a, b) with TpFail -> (None, x)

let check t t' = drop_def t  >>= fun t  ->
                 drop_def t' >>= fun t' -> 
                 catchall (lift (I.check t t')) >>= fun a -> return (bool_of_option a)

(*I am confused as to why the extra catch is necessary...*)
let synth t e = try (drop_def t >>= fun t ->
                 catchall (lift (I.synth t))) e with TpFail -> (None,e)

let is_ax v = getstate >>= fun e ->
                 return (List.exists (function Hax(z,_) when z = v -> true | _ -> false) e)

let rec instantiate a t = 
          let rec aux = function [] -> (false, [])
                       | (Hax (v, e)) :: tl when v = a ->
                               (match check t e tl with
                                 (true,_) -> (true, (Hdef (v, (t, e))) :: tl)
                                |(false,_) -> (false, (Hax (v, e) :: tl)))
                       | h :: t -> let (a, u) = aux t in a, h :: u in aux

let rec forget v =
  getstate >>= fun e ->
   let sub a t = fst (Redbase.subst v a t (fun _ -> false)) in
   let rec aux' a = function [] -> []
                           | Hax (u, t)  :: tl -> Hax(u, sub a t) :: (aux' a tl)
                           | Hdef (u, (t, ty)) :: tl -> Hdef(u, (sub a t, sub a ty)) :: (aux' a tl) in
   let rec aux = function [] -> []
                        | Hdef (u, (t, _)) :: tl when u = v -> aux' t tl
                        | a :: tl -> a :: (aux tl) in
   setstate (aux e)

let rec generalize v e =
  let e = List.rev e in
  let var = function Hdef(v, (_,_)) | Hax (v,_) -> v in
  let dtin (TIn t) = t in
  let synth t = drop_def t >>= fun t -> lift (I.synth t) >>= (function TIn (Uni _) -> return ()
                                                                               | _ -> raise TpFail) in
  let check t t' = drop_def t >>= fun t ->
                   drop_def t' >>= fun t' ->
                   lift (I.check t t') in
  let synth t e = synth t (List.rev e) in
  let check t t' e = check t t' (List.rev e) in
  let nfresh t x = not (fst (is_fresh x t)) in
  let rec aux = function [] -> None
                        |Hax(v', t) :: tl when v = v' -> Some (t, ([],[]), tl)
                        | u :: tl -> match aux tl with
                                      None -> None
                                     |Some (t, (t', tb'), t'') ->
                                      let op o = List.fold_right2
                                         (fun hd hd' t -> if hd' then
                                               Redbase.(>>=) t (Redbase.subst (var hd) 
                                                            (TIn (App (TIn (Var (var hd)), TIn (Var v)))))
                                                          else t)  t' tb' (Redbase.return o) in
                                      match u with
                                       Hax (p,ty) -> let prety = fst (op ty (nfresh t'')) in
                                                      (try let _ = synth prety t'' in
                                                          let re = Hax(p, prety) in
                                                          Some (t, (re :: t', false :: tb'), re :: t'')
                                                      with TpFail ->
                                                      try let ty = TIn (Pi (t, TIn (Bnd(v, dtin ty)))) in
                                                          let _ = synth ty t'' in
                                                          let re = Hax(p, ty) in
                                                          Some (t, (re :: t', true :: tb'), re :: t'')
                                                      with TpFail -> None) (* shouldn't happen *)
                                      |Hdef(p, (te, ty)) -> let te = fst (op te (nfresh t'')) in
                                                            let ty = fst (op ty (nfresh t'')) in
                                                     (try let _ = synth ty t'' in
                                                          let _ = check te ty t'' in
                                                          let re = Hdef(p, (TIn (Annot(te, dtin ty)), ty)) in
                                                          Some(t, (re :: t', false :: tb'), re :: t'')
                                                      with TpFail ->
                                                      let te = TIn (Lam (TIn (Bnd(v, dtin te)))) in
                                                      try let ty = TIn (Forall (t, TIn (Bnd(v, dtin ty)))) in
                                                          let _ = synth ty t'' in
                                                          let _ = check te ty t'' in
                                                          let re = Hdef(p, (TIn (Annot (te, dtin ty)), ty)) in
                                                          Some(t, (re :: t', true :: tb'), re :: t'')
                                                      with TpFail ->
                                                      try let ty = TIn (Pi (t, TIn (Bnd(v, dtin ty)))) in
                                                          let _ = synth ty t'' in
                                                          let _ = check te ty t'' in
                                                          let re = Hdef(p, (TIn (Annot (te, dtin ty)), ty)) in 
                                                          Some(t, (re :: t', true :: tb'), re :: t'')
                                                      with TpFail -> None  (* shouldn't happen either *)) in
  match aux e with
   None -> (false, List.rev e)
  |Some (_, _, e') -> (true, List.rev e')

end

module MyLittlePreTop = PreTop (PreTopbase)
open MyLittlePreTop

let (>>) a b = a >>= (const b)

let bool_of_option = function Some _ -> true | None -> false

let compute t = drop_def t >>= fun t -> (lift (I.fullred t))

let is_type t = synth t >>= (function Some (TIn (Uni _)) -> return true | _ -> return false)

let lexer lexbuf = try Lexer.lexer lexbuf with Failure _ -> raise Parsing.Parse_error

let rec execute : Parser.command -> string t =
 let rebinding_msg v v' = "Warning: " ^ v ^ " was already bound. All previous occurences of " ^ v ^ " were renamed to " ^ v' ^ "." in
 let notatype_msg ty = "Not a Type." in
 let sotm = string_of_tm in function
  Axiom (v, tm) as c  -> is_fresh v >>= (function true -> is_type tm >>=
                                                    (function true -> with_ax v tm (return "Axiom added.")
                                                            | false -> return (notatype_msg tm))
                                           | false -> gensym v >>= fun v' -> rename v v' >> execute c >>= fun s -> return ((rebinding_msg v v') ^ "\n" ^ s))
 |Def (v, t, TIn ty) as c -> is_type (TIn ty) >>=    
                        (function true -> is_fresh v >>=
                                          (function true -> check t (TIn ty) >>=
                                                            (function true  -> with_def v t (TIn ty) (return (v ^ " := " ^ (sotm (TIn (Annot (t, ty))))))
                                                                     |false -> return "Typing failure.") 
                                                         
                                                  | false -> gensym v >>= fun v' -> rename v v' >> execute c >>= fun s ->
                                                             return ((rebinding_msg v v') ^ "\n" ^ s))
                                | false -> return "Not a type.")
 |Definfer (v, t) -> synth t >>= (function Some ty -> execute (Def (v, t, ty)) | None -> return ("Can't infer the type of " ^ (sotm t)))
(*|Check (t, TIn ty)  -> check t (TIn ty) >>=
                        (function true  -> return (sotm (TIn (Annot (t, ty))))
                                 |false -> return "Typing failure.") *)
 |Infer t        -> (try synth t >>=
                    (function Some ty -> return ((sotm t) ^ " :: " ^ (sotm ty))
                             |None          -> return ("Typing failure." )) with TpFail -> return "NOO")
 |Raw t         -> drop_def t >>= fun t' -> return (string_of_tm ~annot:true t')
 |Include filename -> let a  = Lexer.get_eof_action () in
                     (try
                       let f = open_in (filename ^ ".dln") in
                       let () = Lexer.set_eof_action ignore in
                       let cl = Parser.file lexer (Lexing.from_channel f) in
                       List.fold_left (fun s nxt -> s >>= fun s -> 
                            execute nxt >>= fun sn -> return (s ^ "\n" ^ sn))
                                                      (return "") cl >>= fun s ->
                        return (s ^ "\n" ^ filename ^ " imported.")
                      with Sys_error e -> return ("Can't open " ^ filename ^ " : " ^ e ^".")
                          |Parsing.Parse_error -> return "Parse error")
                       >>= fun s -> Lexer.set_eof_action a; 
                                    return ("Including " ^ filename ^ ".\n" ^ s)
 |Import filename -> with_prefix filename (execute (Include filename))
 |Compute t      -> compute t >>= fun t -> return (sotm t)
 |Print           -> string_of_env
 |Restart        -> restart >> return ""
 |Instantiate (v, t) -> is_ax v >>=
                        (function false -> return ("The axiom " ^ v ^ " has not been declared yet.")
                                 |true -> instantiate v t >>=
                                          function true -> return (v ^ " := " ^ (sotm t))
                                                  |false -> return ((sotm t) ^ " is not a valid instance of " ^ v))
 |Generalize v -> generalize v >>=
                  (function false -> return ("Generalization failed for some reason (axiom " ^ 
                                             v ^ "  not declared?) :(")
                           |true  -> return "Success!")
 |Forget v -> is_fresh v >>= fun b -> is_ax v >>= fun u -> return ((not u) && b) >>=
                             (function false -> forget v >> return ("Forgot about " ^ v ^ ".")
                                      |true  -> return (v ^ " is not a definition."))
 |Interpret t -> drop_def t >>= fun t -> Interp.Top.run Interp.Top.loop t; return ""
 | _ -> return "Not Implemented :/"
                   

let step () : unit t = print_string "# "; flush stdout;
                    let c = Parser.comm lexer (Lexing.from_channel stdin) in
                    execute c >>= (fun s -> return (print_endline s))

let rec loop () = let p = print_endline in
                     try (step () >>= loop) with Parsing.Parse_error -> p  "Parse error."; loop ()
                                                |End_of_file         -> p "Goodbye."; return ()
                                                |Sys.Break           -> p "Interrupted."; loop ()


let _ = Sys.catch_break true; Lexer.set_eof_action (fun () -> raise End_of_file); run (loop ())
