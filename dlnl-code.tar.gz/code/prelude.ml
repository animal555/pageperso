let curry f x y = f (x,y)
let uncurry f (x,y) = f x y
let id x = x
let const a b = a
let flip f x y = f y x

let show_debug = ref true
let show_annot = ref false

let do_log ?b:(b = !show_debug) x = if b then print_endline x else ignore x
let bool_of_option = function Some _ -> true | None -> false
let random_letter =
    Random.self_init (); fun () -> String.make 1 (char_of_int ((Random.int 26) + (int_of_char 'a')))

type 'a idty = 'a -> 'a

module type Monad = sig
  type 'a t
  val return : 'a -> 'a t
  val (>>=) : 'a t -> ('a -> 'b t) -> 'b t
end

module type Monoid = sig
  type t
  val empty : t
  val union : t -> t -> t
end

module IdMon : Monad with type 'a t = 'a = struct
  type 'a t = 'a
  let return = id
  let (>>=) a f = f a
end

module type Type = sig
  type t
end

module type PType = sig
  type t
  val v : t
end

module type MonTrans = functor (M : Monad) -> sig
  include Monad
  val lift : 'a M.t -> 'a t
end

module StateMonTrans (T : Type) (M : Monad) :
  sig include Monad with type 'a t = T.t -> ('a * T.t) M.t
      val lift : 'a M.t -> 'a t
      val setstate : T.t -> unit t
      val getstate : T.t t 
      end  = struct

  open M
  type 'a t = T.t -> ('a * T.t) M.t
  let return a e = M.return (a, e)
  let (>>=) a f e = a e >>= uncurry f
  let lift a e = M.(>>=) a (fun b -> M.return (b, e))
  let setstate e (e' : T.t) = M.return ((), e)
  let getstate : T.t t = fun e -> M.return (e, e)
end

module StateMon (T : Type) = StateMonTrans (T) (IdMon)

module type MonadAll = sig
  include Monad
  val (>>) : 'a t -> 'b t -> 'b t
  val map : ('a -> 'b) -> 'a t -> 'b t
  val join : 'a t t -> 'a t
end

module CompleteMon (M : Monad) : MonadAll with type 'a t = 'a M.t = struct
  include M
  let (>>) a b = a >>= const b
  let map f a = a >>= fun b -> return (f b)
  let join a = a >>= id
end
