open Prelude
open Ast
open Red
open Tpchk
(* And it seemed so reasonable before I wrote it... *)


(*FIXME: Not really clean...
         In there because I didn't want to move tptree out of Ast*)
let lctx2ctx = List.map (fun (a, (b, _)) -> (a, b))

module PreITpStateLift (T : PType) (ITp : PreITp_sig) :
  PreITp_sig with type 'a t = T.t -> ('a * T.t) ITp.t
              and type 'a s = T.t -> ('a * T.t) ITp.s = struct
  include (ITp : PreITp_sig with type 'a t := 'a ITp.t
                            with type 'a s := 'a ITp.s)
  module L = StateMonTrans (T) (ITp)
  include L
  type 'a s = T.t -> ('a * T.t) ITp.s
  let forget (a : 'a s) e = forget (a e)
  let run a = fst (run (a T.v))
  let with_var a b (c : 'a t) e = ITp.(>>=) (with_var a b (c e)) ITp.return
  let subst a b c = lift (subst a b c)
  let rename a b c = lift (rename a b c)
  let gensym a = lift (gensym a)
  let whred a = lift (whred a)
  let fullred a = lift (fullred a)
  let conv a b = lift (conv a b)
  let drop_surface_annot a = lift (drop_surface_annot a)
  let drop_annot a = lift (drop_annot a)
  let lookup a = lift (lookup a)
  let ok = lift ok
  let with_irr (c : 'a t) e = ITp.(>>=) (with_irr (c e)) ITp.return
  let getctx = lift getctx
end

module PreLTpStateLift (T : Type) (LTp : PreLTp_sig) :
  PreLTp_sig with type 'a t = T.t -> ('a * T.t) LTp.t
              and type 'a s = T.t -> ('a * T.t) LTp.s = struct
  include (LTp : PreLTp_sig with type 'a t := 'a LTp.t
                            with type 'a s := 'a LTp.s)
  module L = StateMonTrans (T) (LTp)
  include L
  let _ = (lift : 'a LTp.t -> 'a t)
  type 'a s = T.t -> ('a * T.t) LTp.s
  let with_var a b c e = LTp.(>>=) (with_var a b (c e)) LTp.return
  let with_ivar a b c e = LTp.(>>=) (with_ivar a b (c e)) LTp.return
  let subst a b c = lift (subst a b c)
  let rename a b c = lift (rename a b c)
  let gensym a = lift (gensym a)
  let whred a = lift (whred a)
  let fullred a = lift (fullred a)
  let conv a b = lift (conv a b)
  let join a b = a >>= fun a ->  b >>= fun b -> lift (join (LTp.return a) (LTp.return b))
  let drop_surface_annot a = lift (drop_surface_annot a)
  let drop_annot a = lift (drop_annot a)
  let lookup a = lift (lookup a)
  let ok = lift ok
  let with_irr (c : 'a t) e = LTp.(>>=) (with_irr (c e)) LTp.return
  let getctx = lift getctx
  let getictx = lift getictx
  let affinize = lift affinize
  let lift a e = LTp.lift (a e)
end


module ITptree (PreITp: PreITp_sig)
               (LTp : LTp_sig with type 'a t = tptree list -> ('a * tptree list) PreITp.s
                               and type 'a s = tptree list -> ('a * tptree list) PreITp.t) : UnfoldedITp_sig
                              with type 'a s = 'a LTp.t
                               and type 'a t = 'a LTp.s
                       = struct

module I = (PreITpStateLift (struct type t = tptree list
                                     let v = []          end) (PreITp) :
                   PreITp_sig with type 'a t = tptree list -> ('a * tptree list) PreITp.t
                               and type 'a s = tptree list -> ('a * tptree list) PreITp.s)

module I2 = struct
  include I
  
  let (>>) a b = a >>= (const b)
  let getstate e = PreITp.return (e, e)
  let setstate e _ = PreITp.return ((), e)
  let conv a b = getstate >>= fun e ->
                 conv a b >>= fun r ->
                 setstate (Conv(a, b, []) :: e) >>
                 return r
end

module UITp = ITp (I2) (LTp)

include UITp

let (>>) a b = a >>= (const b)
let getstate e = PreITp.return (e, e)
let setstate e _ = PreITp.return ((), e)

let check synth check t t' =
    getctx >>= fun c ->
    getstate >>= fun e ->
    setstate [] >>
      UITp.check synth check t t' >>
      getstate >>= fun e' ->
      setstate (ICheck (c,t,t',e') :: e) >>
      return ()

let synth synth check t =
    getstate >>= fun e ->
    getctx >>= fun c ->
    setstate [] >>
      UITp.synth synth check t >>= fun t' ->
      getstate >>= fun e' ->
      setstate (ISynth (c,t,t',e') :: e) >>
      return t'
end

module LTptree (PreLTp: PreLTp_sig)
               (ITp : ITp_sig with type 'a t = tptree list -> ('a * tptree list) PreLTp.s
                               and type 'a s = tptree list -> ('a * tptree list) PreLTp.t) : UnfoldedLTp_sig
                              with type 'a t = 'a ITp.s
                               and type 'a s = 'a ITp.t
                       = struct

module L = (PreLTpStateLift (struct type t = tptree list end) (PreLTp) :
                   PreLTp_sig with type 'a t = tptree list -> ('a * tptree list) PreLTp.t
                               and type 'a s = tptree list -> ('a * tptree list) PreLTp.s)
module L2 = struct
  include L
  
  let (>>) a b = a >>= (const b)
  let getstate e = PreLTp.return (e, e)
  let setstate e _ = PreLTp.return ((), e)
  let conv a b = getstate >>= fun e ->
                 conv a b >>= fun r ->
                 setstate (Conv(a, b, []) :: e) >>
                 return r
end

module ULTp = LTp (L2) (ITp)

include ULTp

let (>>) a b = a >>= (const b)
let getstate e = PreLTp.return (e, e)
let setstate e _ = PreLTp.return ((), e)

let check synth check t t' =
    getctx >>= fun lc ->
    let lc = lctx2ctx lc in
    getictx >>= fun c ->
    getstate >>= fun e ->
    setstate [] >>
      ULTp.check synth check t t' >>
      getstate >>= fun e' ->
      setstate (LCheck (c,lc,t,t',e') :: e) >>
    return ()

let synth synth check t =
    getctx >>= fun lc ->
    let lc = lctx2ctx lc in
    getictx >>= fun c ->
    getstate >>= fun e ->
    setstate [] >>
      ULTp.synth synth check t >>= fun t' ->
      getstate >>= fun e' ->
      setstate (LSynth (c, lc, t, t', e') :: e) >>
      return t'

end

module rec PreITpImpl : PreITp_sig with type 'a t = 'a it
                                    and type 'a s = 'a lt = PreITp (PreLTpImpl)
       and PreLTpImpl : PreLTp_sig with type 'a t = 'a lt
                                    and type 'a s = 'a it = PreLTp (PreITpImpl)

module rec PreITptreechk : 
                 ITp_sig with type 'a t = tptree list -> ('a * tptree list) it
                                  and type 'a s = tptree list -> ('a * tptree list) lt =
       FoldITp (ITptree (PreITpImpl) (LTptreechk))
and        LTptreechk : LTp_sig with type 'a s = tptree list -> ('a * tptree list) it
                                 and type 'a t = tptree list -> ('a * tptree list) lt =
       FoldLTp (LTptree (PreLTpImpl) (PreITptreechk))

(* Hacky stuff : we Marshal every synthesis to a file *)
module ITptreechk (F : sig val v : string end) : ITp_sig  = struct
  include PreITptreechk

  let getstate e f = ((e, e), f) 

  let synth t =
    synth t >>= fun r ->
    getstate >>= fun l ->
      let f = open_out F.v in
      Marshal.to_channel f l [];
      close_out f;
      return r
end
