open Prelude

type var = string

type 'a tm' =
  Var of var
 |Bnd of var * 'a tm'
 |Annot of 'a * 'a tm'

 |Let of 'a * 'a

 |Uni of int
 |Lin of int
 |UShift of int * 'a
 |Pi of 'a * 'a
 |Sigma of 'a * 'a
 |Gty of 'a
 |Fty of 'a * 'a
 |Lolli of 'a * 'a
 |Tensor of 'a * 'a
 |With of 'a * 'a
 |LPi of 'a * 'a
 |Eq of 'a * 'a * 'a
 |I
 |Unitty
 |Nat
 |Bot
 |Top
 |W of 'a * 'a
 |Plus of 'a * 'a
 |Irr of 'a
 |Forall of 'a * 'a
 |Exists of 'a * 'a

 |Lam of 'a
 |App of 'a * 'a
 |Pair of 'a * 'a
 |Fst of 'a
 |Snd of 'a
 |LetPair of 'a * 'a
 |Unit
 |LetUnit of 'a * 'a
 |Unitind of 'a * 'a * 'a
 |F of 'a * 'a
 |LetF of 'a * 'a
 |WPair of 'a * 'a
 |G of 'a
 |RunG of 'a
 |Refl
 |J of 'a * 'a * 'a
 |Zero
 |Succ of 'a
 |Natind of 'a * 'a * 'a * 'a
 |Botind of 'a
 |Sup of 'a * 'a
 |Wind of 'a * 'a * 'a
 |Inl of 'a
 |Inr of 'a
 |Plusind of 'a * 'a * 'a * 'a
 |Squash of 'a
 |Gen of 'a
 |Pack of 'a * 'a
 |LetPack of 'a * 'a
 |LetIrrPair of 'a * 'a
 |LetIrrUnit of 'a * 'a
 |LetIrr of 'a * 'a

 |Pointsto of 'a * 'a
 |New of 'a
 |LetGet of 'a * 'a * 'a
 |Assign of 'a * 'a * 'a
 |Free of 'a * 'a
 |T of 'a
 |LetT of 'a * 'a
 |Val of 'a
 |Loc
 |Any
 |Get of 'a * 'a

type tm = TIn of tm tm'

let rec map_tm' f = function
 |Var x -> Var x
 |Bnd (v, t) -> Bnd (v, map_tm' f t)
 |Annot (t, t') -> Annot (f t, map_tm' f t')

 |Let (t, t') -> Let (f t, f t')

 |Uni i -> Uni i
 |Lin i -> Lin i
 |UShift (i, t) -> UShift (i, f t)
 |Pi (t, t') -> Pi(f t, f t')
 |Sigma (t, t') -> Sigma(f t, f t')
 |Gty t -> Gty (f t)
 |Fty (t, t') -> Fty (f t, f t')
 |Lolli (t, t') -> Lolli (f t, f t')
 |Tensor (t, t') -> Tensor (f t, f t')
 |With (t, t') -> With (f t, f t')
 |LPi (t, t') -> LPi (f t, f t')
 |Eq (t, t', t'') -> Eq (f t, f t', f t'')
 |I -> I
 |Unitty -> Unitty
 |Nat -> Nat
 |Bot -> Bot
 |Top -> Top
 |W (t, t') -> W (f t, f t')
 |Plus (t, t') -> Plus (f t, f t')
 |Irr t -> Irr (f t)
 |Forall (t, t') -> Forall (f t, f t')
 |Exists (t, t') -> Exists (f t, f t')

 |Lam t -> Lam (f t)
 |App (t, t') -> App (f t, f t')
 |Pair (t, t') -> Pair (f t, f t')
 |Fst t -> Fst (f t)
 |Snd t -> Snd (f t)
 |LetPair (t, t') -> LetPair (f t, f t')
 |Unit -> Unit
 |Unitind (t, t', t'') -> Unitind (f t, f t', f t'')
 |LetUnit (t, t') -> LetUnit (f t, f t')
 |F (t, t') -> F (f t, f t')
 |LetF (t, t') -> LetF (f t, f t')
 |WPair (t, t') -> WPair (f t, f t')
 |G t -> G (f t)
 |RunG t -> RunG (f t)
 |Refl -> Refl
 |J (t, t', t'') -> J (f t, f t', f t'')
 |Zero -> Zero
 |Succ t -> Succ (f t) 
 |Natind (t, t', t'', t''') -> Natind(f t, f t', f t'', f t''')
 |Botind t -> Botind (f t)
 |Sup (t, t') -> Sup (f t, f t')
 |Wind (t, t' , t'') -> Wind (f t, f t', f t'')
 |Inl t -> Inl (f t)
 |Inr t -> Inr (f t)
 |Plusind (t, t', t'', t''') -> Plusind (f t, f t', f t'', f t''')
 |Squash t -> Squash (f t)
 |Gen t -> Gen (f t)
 |Pack (t, t') -> Pack (f t, f t')
 |LetPack (t, t') -> LetPack (f t, f t')
 |LetIrrPair (t, t') -> LetIrrPair(f t, f t')
 |LetIrrUnit (t, t') -> LetIrrUnit(f t, f t')
 |LetIrr (t, t') -> LetIrr (f t, f t') 
 |Get (t, t') -> Get (f t, f t')
 |Free (t, t') -> Free (f t, f t')

 |Pointsto (t, t') -> Pointsto (f t, f t')
 |New t -> New (f t)
 |Assign (t, t', t'') -> Assign (f t, f t', f t'')
 |T t -> T (f t)
 |Loc -> Loc
 |LetT (t, t') -> LetT (f t, f t')
 |LetGet (t, t', t'') -> LetGet (f t, f t', f t'')
 |Val t -> Val (f t)
 |Any -> Any

module Dist (M : Monoid) = struct
  open M

  let rec flatten_tm' : 'a tm' -> M.t = function
    Bnd (v, t) -> flatten_tm' t
   |Annot(t, t') -> union t (flatten_tm' t')
   |Let (t, t')
   |Pi (t, t')
   |Sigma (t, t')
   |Fty (t, t')
   |Lolli (t, t')
   |Tensor (t, t')
   |With (t, t')
   |LPi (t, t')
   |W (t, t')
   |Plus (t, t')
   |App (t, t')
   |Pair (t, t')
   |LetPair (t, t')
   |LetUnit (t, t')
   |F (t, t')
   |LetF (t, t')
   |WPair (t,t')
   |LetIrr (t, t')
   |Pack (t, t')
   |LetPack (t, t')
   |Forall (t, t')
   |Exists (t, t')
   |LetIrrPair (t, t')
   |LetIrrUnit (t, t')
   |Pointsto (t, t')
   |LetT (t, t')
   |Get (t, t')
   |Free (t, t')
   |Sup (t, t') -> union t t'
   |Fst t
   |Snd t
   |Lam t
   |G t
   |Succ t
   |RunG t
   |Botind t
   |Gty t
   |Inl t
   |Squash t
   |Gen t
   |Inr t
   |T t
   |New t
   |Val t
   |UShift (_, t)
   |Irr t -> t
   |J (t, t', t'')
   |Eq (t, t', t'')
   |Wind (t, t', t'')
   |Assign (t, t', t'')
   |LetGet (t, t', t'')
   |Unitind (t, t' , t'') -> union t (union t' t'')
   |Natind (t, t', t'', t''')
   |Plusind (t, t', t'', t''') -> union t (union t' (union t'' t'''))
   |Nat
   |I
   |Zero
   |Bot
   |Top
   |Refl
   |Unitty
   |Uni _
   |Lin _
   |Var _
   |Loc
   |Any
   |Unit -> empty
end

module MList (M : sig type t end) = struct
  type t = M.t list
  let empty = []
  let union = (@) 
  let rec remove x = function [] -> []
                          | h :: t when h = x -> (remove x t)
                          | h :: t -> h :: (remove x t)
end

let rec free_var (TIn t) =
 let module MList_tm = MList (struct type t = tm end) in
 let module D = Dist (MList (struct type t = var end)) in
 match t with
 |Bnd (v,t) -> MList_tm.remove v (free_var (TIn t))
 |Var v -> [v]
 |a -> D.flatten_tm' (map_tm' free_var a)

let rec free_rel_var (TIn t) =
 let module MList_tm = MList (struct type t = tm end) in
 let module D = Dist (MList (struct type t = var end)) in
 match t with
 |Bnd (v,t) -> MList_tm.remove v (free_var (TIn t))
 |Squash t -> []
 |Var v -> [v]
 |a -> D.flatten_tm' (map_tm' free_var a)

let rec is_free_var v (TIn t) =
 let module D = Dist (struct type t = bool let empty = false let union = (||) end) in
 match t with
 |Bnd (v',t) when v' = v -> false
 |Var v' when v = v' -> true
 |Var _ -> false
 |a -> D.flatten_tm' (map_tm' (is_free_var v) a)

let rec is_free_rel_var v (TIn t) =
 let module D = Dist (struct type t = bool let empty = false let union = (||) end) in
 match t with
 |Bnd (v',t) when v' = v -> false
 |Var v' when v = v' -> true
 |Var _ -> false
 |Squash _ -> false
 |a -> D.flatten_tm' (map_tm' (is_free_var v) a)

let rec string_of_tm ?annot:(show_annot = !show_annot) (TIn t) =
  let pv v =
      let sub = 
      function
        0 -> "₀"
       |1 -> "₁"
       |2 -> "₂"
       |3 -> "₃"
       |4 -> "₄"
       |5 -> "₅"
       |6 -> "₆"
       |7 -> "₇"
       |8 -> "₈"
       |9 -> "₉"
       |_ -> raise (Invalid_argument "") in
      let rec aux k =
        try
          let i = int_of_string (String.sub v k 1) in
           (aux (k-1)) ^ (sub i)
        with _ -> String.sub v 0 (k + 1) in
      aux ((String.length v) - 1) in
  let p t = string_of_tm (TIn t) in
  let s = string_of_tm in
  let sg = function (TIn a) -> match a with
                              | Var _
                              | Nat
                              | Bot
                              | Top
                              | Unitty
                              | Uni _
                              | Lin _
                              | I
                              | Unit
                              | Pair (_,_)
                              | WPair (_,_)
                              | Zero -> p a 
                              | _ -> "(" ^ (p a) ^ ")" in
  let is_app = function (TIn a) ->
               match a with
                RunG _
               |G _
               |App _
               |Snd _
               |Botind _
               |Inl _
               |Inr _
               |T _
               |Val _
               |New _
               |Fst _ -> true
               |_ -> false in
  let pg t = sg (TIn t) in
  match t with
  |Var x -> pv x
  |Let (t, TIn (Bnd (x, e))) -> "let " ^ x ^ " = " ^ (s t) ^ " in " ^ (p e)
  |Forall (a, TIn (Bnd (x, e))) 
  |LPi (a, TIn (Bnd (x, e))) 
  |Pi (a, TIn (Bnd (x, e))) -> if is_free_var x (TIn e) then
                               (match t with
                                 LPi (_,_) -> "LΠ"
                                | Pi (_,_)-> "Π"
                                | Forall (_,_) -> "∀"
                                | _ -> assert false) ^ " " ^ (pv x) ^ " : "^(s a) ^ ". " ^ (p e)
                               else
                                 (sg a) ^ " ⟶ " ^ (match e with
                                                     Pi (_, _) -> p e
                                                    |_ -> pg e)
  |Sigma (a, TIn (Bnd (x, e))) -> "Σ " ^ (pv x) ^ " : " ^ (s a) ^ ". " ^ (p e)
  |W (a, TIn (Bnd (x, e))) -> "W " ^ (pv x) ^ " : " ^ (s a) ^ ". " ^ (p e)
  |Fty (a, TIn (Bnd (x, e))) -> "F " ^ (pv x) ^ " : " ^ (s a) ^ ". " ^ (p e)
  |Exists (a, TIn (Bnd (x, e))) -> "∃ " ^ (pv x) ^ " : " ^ (s a) ^ ". " ^ (p e)
  |Gen (TIn Bnd(x, e)) -> "λ <" ^ (pv x) ^">. " ^ (p e)
  |Lam (TIn (Bnd (x, e))) -> "λ " ^ (pv x) ^ ". " ^ (p e)
  |Lolli (a, b) -> (sg a) ^ " ⊸ " ^ (s b)
  |With (a, b) -> (sg a) ^ " & " ^ (s b)
  |Tensor (a, b) -> (sg a) ^ " ⊗ " ^ (s b)
  |Gty a -> "Comp " ^ (sg a)
  |G a -> "G " ^ (sg a)
  |RunG a -> "run " ^ (sg a)
  |App (a, b) -> (if is_app a then s a else sg a) ^ " " ^ (sg b)
  |Fst a -> "π₁ " ^ (sg a)
  |Snd a -> "π₂ " ^ (sg a)
  |LetPair (t, (TIn (Bnd (a, Bnd (b, t'))))) -> "let (" ^ (pv a) ^ ", " ^ (pv b) ^ ") = "
                                                ^ (s t) ^ " in " ^ (p t')
  |LetF (t, (TIn (Bnd (a, Bnd (b, t'))))) -> "let F(" ^ (pv a) ^ ", " ^ (pv b) ^ ") = "
                                                 ^ (s t) ^ " in " ^ (p t')
  |Unitind (TIn (Bnd (x, ty)), t, t') -> "IndUnit(" ^ x ^ ". " ^ (p ty) ^ ", " ^ (s t) ^ ", " ^(s t') ^ ")"
  |LetUnit (t, t') -> "let () = "^ (s t) ^ " in " ^ (s t')
  |Annot (t, t') -> (sg t) ^ (if show_annot then (" :: " ^ (pg t')) else "")
  |F (t, t') -> "F(" ^ (s t) ^ ", " ^ (s t') ^ ")"
  |Pair (t, t') -> "(" ^ (s t) ^ ", " ^ (s t') ^ ")"
  |Unit -> "()"
  |WPair (t, t') -> "[" ^ (s t) ^ ", " ^ (s t') ^ "]"
  |I -> "I"
  |Unitty -> "Unit"
  |Uni i -> "U" ^ (pv (string_of_int i))
  |Lin i -> "L" ^ (pv (string_of_int i))
  |Refl -> "refl"
  |Eq (t, t', t'') -> "Eq " ^ (sg t) ^ " " ^ (sg t') ^ " " ^ (sg t'')
  |J (TIn (Bnd (x, Bnd (y, (Bnd (z, t))))), t', t'') ->
           "J(" ^ (pv x) ^ "." ^ (pv y) ^ "." ^ (pv z) ^ "." ^ (p t) ^ ", " ^ (s t') ^ ", " ^ (s t'') ^ ")"
  |Nat -> "ℕ"
  |Zero -> "0"
  |Succ a -> "S " ^ (sg a) 
  |Natind (TIn (Bnd (z, ty)), a, TIn (Bnd (x, Bnd(y, b))), c) -> "Indℕ(" ^ (pv z) ^ "." ^ (p ty) ^ ", "
                                        ^ (s a) ^ ", " ^ (pv x) ^ "." ^ (pv y) ^ "." ^ (p b) ^ ", " ^ (s c) ^ ")"
  |Bot -> "⊥"
  |Top -> "⊤"
  |Botind a -> "Ind⊥ " ^ (sg a)
  |Wind (TIn (Bnd (z, ty)), TIn (Bnd (a, Bnd(f, Bnd (r, t)))), w) ->
      "IndW(" ^ (pv z) ^ "." ^ (p ty) ^ ", " ^ (pv a) ^ "." ^ (pv f) ^ "." ^ (pv r) ^ "." ^ (p t) ^ ", " ^ (s w) ^ ")"
  |Sup (a, b) -> "sup " ^ (sg a) ^ " " ^ (sg b)
  |Inl a -> "inl " ^ (sg a)
  |Inr a -> "inr " ^ (sg a)
  |Plusind (TIn (Bnd (x,ty)), TIn (Bnd (a,ca)), TIn (Bnd (b, cb)), w) ->
     "Ind+("^ (pv x) ^ ". " ^ (p ty) ^ ", " ^ (pv a) ^ ". " ^ (p ca) ^ ", " ^ (pv b) ^ ". " ^ (p cb) ^", " ^ (s w) ^ ")"
  |Plus (a, b) -> (s a) ^ " + " ^ (s b)
  |Irr a -> "[ " ^ (s a) ^ " ]"
  |Squash a -> "< " ^ (s a) ^ " >"
  |Pack (a, b) -> "Pack(" ^ (s a) ^ ", " ^ (s b) ^ ")"
  |LetPack (a, TIn (Bnd(x, Bnd (y, b)))) -> "let Pack(" ^ (pv x) ^ ", " ^ (pv y) ^ ") = " ^ (s a) ^ " in " ^ (p b)
  |LetIrrPair (a, TIn (Bnd(x, Bnd (y, b)))) -> "let <" ^ (pv x) ^ ", " ^ (pv y) ^ "> = " ^ (s a) ^ " in " ^ (p b)
  |LetIrrUnit (a, b) -> "let <()> = " ^ (s a) ^ " in " ^ (s b)
  |LetIrr (a, TIn Bnd(x, b)) -> "let < " ^ (pv x) ^ " > = " ^ (s a) ^ " in " ^ (p b)
  |Free (t, t') -> "free (" ^ (s t) ^ ", " ^ (s t') ^ ")"
  |Assign (t, t', t'') -> (sg t) ^ " <-[ " ^ (s t') ^ " ]- " ^ (sg t'')
  |Pointsto (t, t') -> (sg t) ^ " |-> " ^ (sg t')
  |LetGet (t, t', TIn (Bnd(x, Bnd(a, t'')))) -> "let (" ^ (pv x) ^ ", " ^ (pv a) ^ ") = get (" ^ (s t) ^ ", " ^ (s t') ^ ") in " ^ (p t'')
  |New t -> "new " ^ (sg t)
  |Val t -> "val " ^ (sg t)
  |T t -> "T " ^ (sg t)
  |Loc -> "Loc"
  |LetT (t, TIn ( Bnd(x, t'))) -> "let val " ^ (pv x) ^ " = " ^ (s t) ^ " in " ^ (p t')
  |Any -> "Any"
  |Bnd(x, t) -> "{" ^ x ^ "} " ^ (p t)
  |UShift (i, t) -> if i <> 0 then
                     (if i > 0 then "↑"
                       else "↓") ^ (if (abs i) <> 1 then (string_of_int (abs i)) ^ " " else " ") ^ (sg t)
                    else s t
  |_  -> "FIXME: no pretty-printing for this"
  

let rec drop_annot (TIn t) =
  match t with
   Annot (t, t') -> drop_annot t
  | t -> TIn (map_tm' drop_annot t)

let rec drop_surface_annot (TIn t) = match t with Annot (t, t') -> drop_surface_annot t | t -> TIn t

let rec ushift i (TIn t) =
  match t with
   Uni j -> TIn (Uni (j + i))
  |Lin j -> TIn (Lin (j + i))
  | t -> TIn (map_tm' (ushift i) t)

type ctx = (var * tm) list
type tptree =
  Conv of  tm * tm * tptree list
 |ISynth of ctx * tm * tm * tptree list
 |LSynth of ctx * ctx * tm * tm * tptree list
 |ICheck of ctx * tm * tm * tptree list
 |LCheck of ctx * ctx * tm * tm * tptree list
 |Fail
