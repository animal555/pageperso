#!/bin/zsh
rlwrap ocaml prelude.cmo ast.cmo red.cmo parser.cmo lexer.cmo tpchk.cmo deriv.cmo debug.cmo
